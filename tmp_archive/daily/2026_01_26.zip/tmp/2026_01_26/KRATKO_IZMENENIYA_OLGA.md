# КРАТКИЙ ОТЧЁТ ОБ ИЗМЕНЕНИЯХ
**От пользователя:** Olga (DBA)
**Дата:** 26 января 2026
**Ветка:** feature/tz-26-12-critical-fixes

---

## 📝 ИЗМЕНЕНИЯ

### Файл: `/var/www/komunal-dom_ru/filter_detection_service.py`

**Место 1:** Строки 469-474 (`_create_category_prompt()`)

**Было:**
```python
M_CANDIDATE = {{}}
for cat in CATEGORIES:
    M_CANDIDATE[cat] = round(M_OBJ[cat] * M_EVENT[cat] * M_PLACE[cat], 3)
```

**Стало:**
```python
M_CANDIDATE = {{}}
# ИСПРАВЛЕНО (2026-01-26): Убран M_PLACE из умножения!
for cat in CATEGORIES:
    M_CANDIDATE[cat] = round(M_OBJ[cat] * M_EVENT[cat], 3)
```

---

**Место 2:** Строки 876-881 (`_create_filter_detection_prompt()` - старый метод)

Применено аналогичное исправление.

---

## 🎯 СУТЬ ИЗМЕНЕНИЯ

**Формула:**
- **Было:** `M_CANDIDATE = M_OBJ × M_EVENT × M_PLACE`
- **Стало:** `M_CANDIDATE = M_OBJ × M_EVENT`

**Причина:**
Если PLACE не указан → M_PLACE = [0,0,...] → всё × 0 → category = null

**Результат:**
- "Когда включат горячую воду?" → было **null**, стало **Водоснабжение** ✅

---

## ✅ ВНЕДРЕНО

| Действие | Статус |
|----------|--------|
| Код изменён | ✅ (2 места) |
| Кэш очищен | ✅ |
| Gunicorn перезапущен | ✅ |
| Git commit | ✅ 3549d3b |
| Git push | ✅ |

---

**Дата:** 26 января 2026, 14:44 UTC
**Коммит:** 3549d3b
