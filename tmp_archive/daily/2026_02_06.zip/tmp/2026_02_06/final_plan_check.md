# ФИНАЛЬНАЯ ПРОВЕРКА ПЛАНА

## ПРОВЕРКА ФАЗЫ 1: Группировка моделей

### Шаг 1.1: portal/models.py
НЕОБХОДИМО ИЗМЕНИТЬ:
- UserProfile: app_label = 'auth'
- AIPrompt: app_label = 'ai_and_prompts'
- SemanticPattern: app_label = 'references'
- ServicesCatalog: app_label = 'references'

### Шаг 1.2: llm_tester/models.py
НЕОБХОДИМО ИЗМЕНИТЬ:
- PromptTemplate: app_label = 'ai_and_prompts'
- PromptPreset: app_label = 'ai_and_prompts'
- LLMTestResult: app_label = 'ai_and_prompts'

### Шаг 1.3: message_handler/models.py
НЕОБХОДИМО ПРОВЕРИТЬ:
- MessageLog: app_label = 'logs'
- CommunicativeScript: app_label = 'logs'

## ПРОВЕРКА ФАЗЫ 2: Защита боевых промптов

### Изменения в portal/models.py:
Добавить поле is_test в AIPrompt

### Изменения в portal/admin.py:
- Добавить отображение меток 🔴🟡
- Ограничить права для боевых промптов
- Запретить удаление боевых промптов

### Изменения в коде бота:
- Добавить фильтр is_test=False при загрузке промптов

## ПРОВЕРКА ФАЗЫ 3: Интеграция LLM Tester

### Кнопка в админке:
- URL: /llm-tester/test/{template_id}/

### Кнопка возврата:
- URL: /admin/llm_tester/prompttemplate/

