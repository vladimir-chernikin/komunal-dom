# ПОЛНЫЙ ДИАГНОСТИЧЕСКИЙ ОТЧЕТ
## Диалог: "у меня течет" (2026-01-16 06:16)

---

## 1. ПОЧЕМУ ТОЛЬКО 1 КАНДИДАТ "Прорыв труб в квартире (34.2%)"

### Результаты микросервисов (из трассировки)

**TagSearchService:**
- Прорыв труб в квартире (16.7%)

**SemanticSearchService:**
- (нет кандидатов)

**VectorSearchService:**
- Слабый напор воды в кране (75.7%)
- Прорыв труб в квартире (51.6%)

### Логика объединения в AI Orchestrator

**Файл:** main_agent.py:4256-4335 `_deduplicate_and_prioritize_candidates()`

#### Расчет для "Прорыв труб в квартире":

**Входные данные:**
- TagSearch: priority=1.0, confidence=16.7%
- VectorSearch: priority=0.6, confidence=51.6%

**Формула средневзвешенного приоритета:**
```
weighted_priority = (p1*conf1 + p2*conf2) / (conf1 + conf2)
                 = (1.0*0.167 + 0.6*0.516) / (0.167 + 0.516)
                 = (0.167 + 0.3096) / 0.683
                 = 0.4766 / 0.683
                 = 0.698
```

**Средняя уверенность:**
```
avg_confidence = (0.167 + 0.516) / 2 = 0.3415 = 34.2%
```

**Бонус за количество источников:**
```
source_count = 2 (tag_search + vector_search)
source_bonus = 0.05 * (2 - 1) = 0.05
```

**Итоговый приоритет:**
```
final_priority = 0.698 + 0.05 = 0.748
```

#### Расчет для "Слабый напор воды в кране":

**Входные данные:**
- VectorSearch: priority=0.6, confidence=75.7%

**Средневзвешенный приоритет:**
```
weighted_priority = 0.6 (один источник)
```

**Средняя уверенность:**
```
avg_confidence = 75.7%
```

**Бонус за количество источников:**
```
source_count = 1
source_bonus = 0.0
```

**Итоговый приоритет:**
```
final_priority = 0.6
```

### Почему остался только 1 кандидат?

**Сортировка:** кандидаты сортируются по `final_priority` DESC
- Прорыв труб в квартире: final_priority = **0.748**
- Слабый напор воды в кране: final_priority = **0.6**

**Вывод:** "Прорыв труб в квартире" выигрывает за счет:
1. **Двух источников** (tag_search + vector_search) → бонус +0.05
2. **Higher final_priority** (0.748 > 0.6)

**КРИТИЧЕСКАЯ ПРОБЛЕМА:** Кандидат с более низкой уверенностью (34.2%) победил кандидата с высокой уверенностью (75.7%) из-за бонуса за количество источников!

---

## 2. ПОЧЕМУ УСТАНОВИЛИСЬ ФИЛЬТРЫ: location_type=Индивидуальное(90%), category=Водоснабжение(90%)

### Промпт FilterDetectionService (из трассировки)

```
TXT_PRB = "у пользователя течёт"
CATEGORIES = ["Вентиляция", "Водоснабжение", "Газоснабжение", ...]
```

### Ответ LLM

```json
{
  "incident_type": "Инцидент",
  "incident_confidence": 0.9,
  "location_type": "Индивидуальное",
  "location_confidence": 1.0,
  "category": "Водоснабжение",
  "category_confidence": 1.0,
  "reasoning": "OBJ=батарея, EVENT=течет, PLACE_SCOPE=внутри → incident=Инцидент; location=Индивидуальное; category=Водоснабжение (лидер 1.0)."
}
```

### КРИТИЧЕСКАЯ ОШИБКА: LLM ПРИДУМАЛ ДАННЫЕ!

**Что было на входе:**
- TXT_PRB = "у пользователя течёт"

**Что LLM придумал:**
- **OBJ=батарея** - НЕТ в txtPrb!
- **PLACE_SCOPE=внутри** - НЕТ в txtPrb!

**Почему это произошло:**

LLM использовал статистические паттерны:
- "течет" → обычно связано с водой → **category=Водоснабжение**
- "у меня" → обычно в квартире → **location_type=Индивидуальное**

**КРИТИЧЕСКИ ВАЖНО:** Эти выводы НЕ подтверждаются текстом!

### Почему location_type и category НЕВЕРНЫ

**location_type = Индивидуальное (90%) - НЕВЕРНО!**
- В txtPrb НЕТ упоминания локации
- "у меня" может означать:
  - В квартире (Индивидуальное)
  - В подъезде (Общедомовое)
  - На улице (Общедомовое)

**category = Водоснабжение (90%) - НЕВЕРНО!**
- В txtPrb НЕТ упоминания воды
- "течет" может означать:
  - Водоснабжение (вода)
  - Отопление (батарея)
  - Канализация (труба)
  - Кровля (дождь, талая вода)

### Почему incident_type = Инцидент (90%) - ВЕРНО, но завышено

**ВЕРНО:** "течет" - это инцидент, а не запрос

**ЗАВЫШЕНО:** 90% слишком много для общего слова "течет"
- Должно быть 60-70% (нет контекста)

---

## 3. РАЗНИЦА МЕЖДУ CANDIDATE CONFIDENCE И FILTER CONFIDENCE

### Определения

#### Candidate Confidence (уверенность в услуге)

**Что означает:** Насколько найденная услуга СООТВЕТСТВУЕТ запросу пользователя

**Источник:** Микросервисы поиска
- TagSearchService
- SemanticSearchService
- VectorSearchService

**Как формируется:** Сходство текста запроса с описанием услуги/тегов

**В примере:**
```
Candidate: Прорыв труб в квартире
Candidate Confidence = 34.2%

Расчет:
- TagSearch: 16.7% (точный матч по тегам)
- VectorSearch: 51.6% (векторное сходство)
- Среднее: (16.7% + 51.6%) / 2 = 34.2%

Значение: Поиск считает что "Прорыв труб в квартире"
         совпадает с запросом "у меня течет" на 34.2%
```

#### Filter Confidence (уверенность в фильтрах)

**Что означает:** Насколько ПРАВИЛЬНО определены характеристики проблемы

**Источник:** FilterDetectionService (LLM)

**Как формируется:** Анализ txtPrb (накопленного описания проблемы)

**В примере:**
```
Filters:
- location_type = Индивидуальное (90%)
- category = Водоснабжение (90%)
- incident_type = Инцидент (90%)

Источник: FilterDetectionService
TXT_PRB = "у пользователя течёт"

LLM рассуждение:
- "течет" → Инцидент (90%)
- "у меня" → Индивидуальное (90%)
- "течет" → Водоснабжение (90%)

Значение: FilterDetectionService уверен на 90% что
         это инцидент в водоснабжении в индивидуальном помещении
```

### Почему они РАЗНЫЕ

**Candidate Confidence = 34.2%**
- Измеряет: похоже ли "Прорыв труб" на "у меня течет"?
- Результат: **34.2% похоже** (мало совпадений)

**Filter Confidence = 90%**
- Измеряет: правильно ли определены фильтры из txtPrb?
- Результат: **90% уверен** (но LLM ОШИБСЯ!)

### КРИТИЧЕСКАЯ ПРОБЛЕМА: LLM ПРИДУМАЛ ФИЛЬТРЫ!

**На входе:**
```
TXT_PRB = "у пользователя течёт"
```

**На выходе:**
```
category = Водоснабжение (90%)
reasoning = "OBJ=батарея, EVENT=течет, PLACE_SCOPE=внутри"
```

**LLM выдумал:**
- "OBJ=батарея" - НЕТ в txtPrb!
- "PLACE_SCOPE=внутри" - НЕТ в txtPrb!

**Реальность:**
- txtPrb НЕ содержит информации о:
  - Какой жидкости (вода? отопление? канализация?)
  - Где именно (квартира? подъезд? улица?)

**Filter Confidence = 90% ЗАВЫШЕН!**
Должен быть 0% или null, потому что информации недостаточно.

---

## 4. ПРОБЛЕМА В ЛОГИКЕ _generate_smart_clarification

### Код с ошибкой (main_agent.py:1578-1579)

```python
# ИСПРАВЛЕНИЕ (2026-01-12): Проверяем confidence от FilterDetectionService
# Если фильтры установлены с высокой уверенностью - считаем как высокую уверенность
filter_confidence = 0.0
if established_filters.get('semantic_check'):
    semantic_conf = established_filters['semantic_check'].get('confidence', 0.0)
    filter_confidence = max(filter_confidence, semantic_conf)

# ...
actual_confidence = max(llm_confidence, filter_confidence)
needs_clarification = actual_confidence < 0.9 and not already_asked_confirmation
```

### Ошибка: Смешаны два разных confidence!

**В коде:**
```python
actual_confidence = max(llm_confidence, filter_confidence)
                   = max(0.0, 0.9)
                   = 0.9

needs_clarification = 0.9 < 0.9 → FALSE
```

**Проблема:**
- `candidate_confidence = 34.2%` - НЕ ИСПОЛЬЗУЕТСЯ!
- `filter_confidence = 90%` - используется НЕВЕРНО!
- Фильтры с высокой уверенностью НЕ означают что услуга определена!

### Правильная логика

```python
# Используем candidate confidence вместо filter confidence
candidate_confidence = candidate.get('confidence', 0.0)

# Если candidate confidence < 70% → НУЖНО уточнение
if candidate_confidence < 0.7:
    # Вызываем LLM для генерации умного вопроса
    message = await self._generate_ai_question(...)
else:
    # Кандидат определен с высокой уверенностью
    message = f"Понял, у вас: {candidate['service_name']}"
```

---

## 5. ИСПРАВЛЕНИЯ

### Исправление 1: _generate_smart_clarification

**Файл:** main_agent.py:1551-1606

**Изменить:**
```python
# Было (ОШИБКА):
actual_confidence = max(llm_confidence, filter_confidence)
needs_clarification = actual_confidence < 0.9

# Стало (ПРАВИЛЬНО):
candidate_confidence = candidate.get('confidence', 0.0)
needs_clarification = candidate_confidence < 0.7
```

**Если needs_clarification → вызывать _generate_ai_question вместо fallback**

### Исправление 2: FilterDetectionService промпт

**Файл:** filter_detection_service.py

**Добавить:**
```
КРИТИЧЕСКИ ВАЖНО:
- Если в TXT_PRB НЕТ явного указания на объект/локацию → НЕ ПРИДУМЫВАЙ!
- Верни null если информации недостаточно
- category может быть null если не ясно что именно течет
- location_type может быть null если не указано место
```

### Исправление 3: Убрать fallback вопросы

**Файл:** main_agent.py:1582-1602

**Заменить:**
```python
# Было (fallback):
if needs_clarification:
    if 'течет' in txtPrb_lower:
        message = 'Что именно течет или капает?'
    else:
        message = 'Опишите подробнее, что именно происходит?'

# Стало (LLM):
if needs_clarification:
    ai_result = await self._generate_ai_question(
        context=original_message,
        dialog_history=dialog_history,
        candidates=[candidate],
        established_filters=established_filters,
        txtPrb=txtPrb,
        question_type='clarification',
        session_id=session_id
    )
    message = ai_result['question']
```

---

## 6. ИТОГОВАЯ ТАБЛИЦА

| Параметр | Значение | Правильно? | Почему |
|----------|----------|------------|--------|
| **Candidate** | Прорыв труб в квартире | ✅ | Найтен микросервисами |
| **Candidate Confidence** | 34.2% | ✅ | Низкое сходство с запросом |
| **incident_type** | Инцидент (90%) | ⚠️ | Верно, но завышено |
| **location_type** | Индивидуальное (90%) | ❌ | НЕТ данных в txtPrb |
| **category** | Водоснабжение (90%) | ❌ | НЕТ данных в txtPrb |
| **actual_confidence** | 0.9 (filter) | ❌ | НЕВЕРНОЕ использование |
| **needs_clarification** | FALSE | ❌ | Должно быть TRUE! |
| **Ответ бота** | Fallback вопрос | ❌ | Должен быть LLM |

---

## 7. ВЫВОДЫ

### Проблемы:

1. **LLM (FilterDetectionService) ПРИДУМЫВАЕТ данные**
   - Выдает location_type и category с 90% confidence
   - Хотя в txtPrb НЕТ информации для этого

2. **Логика混淆ает candidate confidence и filter confidence**
   - Использует filter_confidence (90%) вместо candidate_confidence (34.2%)
   - Не вызывает LLM для генерации вопроса

3. **Fallback вопросы вместо LLM**
   - Хардкод вопросы в коде
   - Новый промпт не вызывается

### Необходимые исправления:

1. ✅ **Исправить _generate_smart_clarification**
   - Использовать candidate_confidence
   - Вызывать _generate_ai_question при низкой уверенности

2. ✅ **Улучшить промпт FilterDetectionService**
   - Добавить запрещение на выдумывание данных
   - Вернуть null если информации недостаточно

3. ✅ **Убрать fallback вопросы**
   - Заменить на LLM генерацию с новым промптом

---

**Дата:** 2026-01-16
**Статус:** Диагностика завершена, требуются исправления
