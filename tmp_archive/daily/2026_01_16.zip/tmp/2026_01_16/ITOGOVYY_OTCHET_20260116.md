# ИТОГОВЫЙ ОТЧЕТ ПО ИСПРАВЛЕНИЯМ
## Дата: 2026-01-16

---

## 1. ОТВЕТЫ НА ВОПРОСЫ

### 1.1. Почему только 1 кандидат "Прорыв труб в квартире (34.2%)"?

**Результаты микросервисов:**
- TagSearchService: Прорыв труб в квартире (16.7%)
- SemanticSearchService: (нет кандидатов)
- VectorSearchService:
  - Слабый напор воды в кране (75.7%)
  - Прорыв труб в квартире (51.6%)

**Логика объединения (AI Orchestrator):**

Для "Прорыв труб в квартире":
```
sources: TagSearch (priority=1.0, conf=16.7%) + VectorSearch (priority=0.6, conf=51.6%)
avg_confidence = (16.7% + 51.6%) / 2 = 34.2%
source_count = 2 → source_bonus = 0.05
final_priority = 0.698 + 0.05 = 0.748
```

Для "Слабый напор воды в кране":
```
sources: VectorSearch (priority=0.6, conf=75.7%)
avg_confidence = 75.7%
source_count = 1 → source_bonus = 0.0
final_priority = 0.6
```

**Почему остался 1 кандидат:**
Кандидаты сортируются по final_priority DESC:
- Прорыв труб: 0.748 (ВЫШЕ)
- Слабый напор: 0.6 (НИЖЕ)

**Проблема:** Кандидат с более низкой уверенностью (34.2%) победил за счет бонуса за 2 источника!

---

### 1.2. Почему установились фильтры: location_type=Индивидуальное(90%), category=Водоснабжение(90%)?

**Ответ LLM FilterDetectionService:**
```json
{
  "location_type": "Индивидуальное",
  "location_confidence": 1.0,
  "category": "Водоснабжение",
  "category_confidence": 1.0,
  "reasoning": "OBJ=батарея, EVENT=течет, PLACE_SCOPE=внутри"
}
```

**КРИТИЧЕСКАЯ ОШИБКА:** LLM ПРИДУМАЛ данные!
- В txtPrb = "у пользователя течёт"
- **НЕТ слова "батарея"!**
- **НЕТ указания "внутри"!**

**Почему это произошло:**
LLM использовал статистические паттерны:
- "течет" → обычно вода → category=Водоснабжение
- "у меня" → обычно квартира → location_type=Индивидуальное

**Вердикт:**
- ✅ incident_type=Инцидент — ВЕРНО, но завышено (90% должно быть 60-70%)
- ❌ location_type=Индивидуальное — НЕВЕРНО (нет данных в txtPrb)
- ❌ category=Водоснабжение — НЕВЕРНО (нет данных в txtPrb)

---

### 1.3. Разница между Candidate Confidence и Filter Confidence

**Candidate Confidence (34.2%):**
- **Что означает:** Насколько услуга СООТВЕТСТВУЕТ запросу
- **Источник:** Микросервисы поиска (TagSearch, VectorSearch)
- **Расчет:** (16.7% + 51.6%) / 2 = 34.2%
- **Смысл:** Поиск считает что "Прорыв труб" совпадает с "у меня течет" на 34.2%

**Filter Confidence (90%):**
- **Что означает:** Насколько ПРАВИЛЬНО определены характеристики проблемы
- **Источник:** FilterDetectionService (LLM)
- **Расчет:** LLM оценил уверенность в фильтрах
- **Смысл:** LLM уверен на 90% что это Инцидент в Индивидуальном помещении в категории Водоснабжение

**КРИТИЧЕСКАЯ ПРОБЛЕМА:**
Filter Confidence = 90% ЗАВЫШЕН, потому что LLM ПРИДУМАЛ данные из txtPrb!

**Пример:**
```
txtPrb = "у пользователя течёт"

LLM рассуждение (ОШИБКА):
- "течет" → OBJ=батарея (НЕТ в тексте!)
- "у меня" → PLACE_SCOPE=внутри (НЕТ в тексте!)
- → category=Водоснабжение (НЕВЕРНЫЙ вывод!)
- → filter_confidence=90% (ЗАВЫШЕНО!)
```

---

## 2. ИСПРАВЛЕНИЯ В КОДЕ

### Исправление 1: _generate_smart_clarification

**Файл:** main_agent.py:1551-1611

**Было (ОШИБКА):**
```python
# Смешивались два разных confidence!
filter_confidence = 0.9  # Из FilterDetectionService
actual_confidence = max(llm_confidence, filter_confidence)
needs_clarification = actual_confidence < 0.9  # = FALSE
# Использовался fallback вопрос
```

**Стало (ПРАВИЛЬНО):**
```python
# Используем candidate confidence
candidate_confidence = candidate.get('confidence', 0.0)  # 34.2%
needs_clarification = candidate_confidence < 0.7  # = TRUE

# Вызываем LLM для генерации вопроса (НЕ fallback!)
ai_result = await self._generate_ai_question(
    context=original_message,
    dialog_history=dialog_history,
    candidates=[candidate],
    established_filters=established_filters,
    txtPrb=txtPrb,
    question_type='clarification',
    session_id=session_id
)
message = ai_result['question']
```

**Что изменилось:**
- ✅ Используется candidate_confidence (из микросервисов)
- ✅ Порог 70% вместо 90%
- ✅ Вызов _generate_ai_question вместо fallback вопросов
- ✅ Новый промпт будет выполняться

---

### Исправление 2: FilterDetectionService промпт

**Файл:** filter_detection_service.py:174-182

**Добавлено КРИТИЧЕСКОЕ ПРАВИЛО:**
```
⛔ КРИТИЧЕСКИ ВАЖНО: НЕ ПРИДУМЫВАЙ ДАННЫЕ!
- Если в TXT_PRB НЕТ явного указания на объект/локацию/категорию → верни null!
- НЕ используй статистические предположения ("обычно это вода", "скорее в квартире")
- ТОЛЬКО явные упоминания из текста!

Пример:
- TXT_PRB = "у меня течет" → OBJ=null, PLACE=null (НЕПРАВИЛЬНО: OBJ=батарея, PLACE=внутри)
- TXT_PRB = "течет батарея в зале" → OBJ=батарея, PLACE=зал (ПРАВИЛЬНО)
```

**Что изменится:**
- ✅ LLM НЕ будет придумывать объекты из статистики
- ✅ location_type и category будут null если не указаны явно
- ✅ Filter confidence будет корректным (0.5 вместо 0.9)

---

## 3. УБРАНЫ FALLBACK ВОПРОСЫ

**Было (хардкод вопросы):**
```python
if needs_clarification:
    if 'течет' in txtPrb_lower:
        message = 'Что именно течет или капает?'
    else:
        message = 'Опишите подробнее, что именно происходит?'
```

**Стало (LLM генерация):**
```python
if needs_clarification:
    # Вызываем _generate_ai_question с новым промптом
    ai_result = await self._generate_ai_question(...)
    message = ai_result['question']
```

**Что изменилось:**
- ✅ Все вопросы генерируются через LLM с новым промптом
- ✅ Учитываются кандидаты, фильтры, txtPrb, история
- ✅ Нет хардкода вопросов

---

## 4. ПРОВЕРКА ИСПРАВЛЕНИЙ

### Тестовый сценарий:
1. Пользователь: "привет"
2. Пользователь: "у меня течет"

**Ожидаемое поведение:**
1. ✅ txtPrb = "у пользователя течёт"
2. ✅ Candidate: Прорыв труб в квартире (34.2%)
3. ✅ FilterDetectionService:
   - location_type = null (НЕПРАВИЛЬНО: Индивидуальное)
   - category = null (НЕПРАВИЛЬНО: Водоснабжение)
   - incident_type = Инцидент (70%) (ПРАВИЛЬНО)
4. ✅ candidate_confidence = 34.2% < 70% → needs_clarification = TRUE
5. ✅ Вызов _generate_ai_question с новым промптом
6. ✅ LLM генерирует умный вопрос с учетом txtPrb и кандидатов

---

## 5. ФАЙЛЫ С ИСПРАВЛЕНИЯМИ

1. **main_agent.py** (строки 1551-1611)
   - Исправлена логика в _generate_smart_clarification
   - Используется candidate_confidence
   - LLM генерация вместо fallback

2. **filter_detection_service.py** (строки 174-182)
   - Добавлено правило "НЕ ПРИДУМЫВАЙ ДАННЫЕ"
   - Примеры правильного/неправильного поведения

3. **Бот перезапущен:** ✅ active (running)

---

## 6. ДОКУМЕНТАЦИЯ

**Созданы файлы:**
- `/tmp/ANALYSIS_full_diagnostics_20260116.md` — Полная диагностика
- `/tmp/ANALYSIS_new_prompt_issue.md` — Анализ проблемы с промптом
- `/tmp/ITOGOVYY_OTCHET_20260116.md` — Этот файл

---

## 7. СЛЕДУЮЩИЕ ШАГИ

1. ✅ Код исправлен
2. ✅ Бот перезапущен
3. ⏳ Протестировать диалог "у меня течет"
4. ⏳ Проверить что LLM генерирует вопросы с новым промптом
5. ⏳ Проверить что FilterDetectionService не придумывает фильтры

---

**Статус:** Исправления применены, ожидается тестирование
**Дата:** 2026-01-16
**Версия:** feature/tz-26-12-critical-fixes
