# АНАЛИЗ: Почему новый промпт не сработал в диалоге 06:16

## Диалог из трассировки

**Session ID:** telegram_1049252307_20260116_061616
**Сообщение:** "у меня течет"
**txtPrb:** "у пользователя течёт"

## Результаты поиска

1. **TagSearchService:** Прорыв труб в квартире (16.7%)
2. **SemanticSearchService:** (нет кандидатов)
3. **VectorSearchService:**
   - Слабый напор воды в кране (75.7%)
   - Прорыв труб в квартире (51.6%)

**Итоговое объединение:**
- Прорыв труб в квартире (34.2%)

## Установленные фильтры

- location_type = Индивидуальное (90%)
- category = Водоснабжение (90%)
- incident_type = Инцидент (90%)

## Ответ бота

"Опишите подробнее, что именно происходит?"

## Проблема

**НЕТ вызова LLM с моделью `pro` для генерации вопроса!**

В llm_request_log только 4 вызова модели `lite`:
1. ProblemAccumulationService
2. FilterDetectionService (2 вызова)

## Корень проблемы

### Проблема 1: Логика в _generate_smart_clarification

**Файл:** main_agent.py, строки 1578-1579

```python
actual_confidence = max(llm_confidence, filter_confidence)
needs_clarification = actual_confidence < 0.9 and not already_asked_confirmation
```

**Ошибка:**
- `llm_confidence` - confidence из LLM ранжирования (0.0, т.к. 1 кандидат)
- `filter_confidence` - confidence ФИЛЬТРОВ из FilterDetectionService (0.9)
- **НЕ используется candidate confidence = 34.2%!**

**Расчет:**
```
actual_confidence = max(0.0, 0.9) = 0.9
needs_clarification = 0.9 < 0.9 → FALSE
```

Результат: `needs_clarification = False` → используется fallback вопрос, НЕ LLM генерация!

### Проблема 2: Fallback вопросы вместо LLM

**Файл:** main_agent.py, строки 1582-1602

```python
if needs_clarification:
    # Контекстные вопросы
    if 'течет' in txtPrb_lower:
        message = 'Что именно течет или капает?'
    else:
        message = 'Опишите подробнее, что именно происходит?'
```

**Это НЕ LLM генерация!** Это хардкод вопросы!

### Проблема 3: _determine_strategy не вызывается

В методе `_generate_smart_clarification` для 1 кандидата:
- НЕ вызывается `_determine_strategy()`
- НЕ вызывается `_generate_ai_question()` с новым промптом
- Используются fallback вопросы

## Почему новый промпт не сработал

**Новый промпт находится в методе `_build_dynamic_prompt()`**, который вызывается ТОЛЬКО из `_generate_ai_question()`.

Но `_generate_ai_question()` НЕ вызывается из `_generate_smart_clarification()` для случая 1 кандидата!

**Путь выполнения:**
1. `process_service_detection()` → поиск кандидатов
2. `_create_ambiguous_result()` → `_generate_smart_clarification()`
3. `_generate_smart_clarification()` → если 1 кандидат
   - Проверяет actual_confidence (НЕ ПРАВИЛЬНО!)
   - Использует fallback вопросы (НЕ ПРАВИЛЬНО!)

**Должно быть:**
```
_generate_smart_clarification() →
  если 1 кандидат с confidence < 70%:
    → _generate_ai_question(candidates=[candidate], strategy='NONE')
```

## Решение

### Вариант 1: Исправить _generate_smart_clarification

**Изменить логику в строках 1551-1606:**

1. Передавать candidate confidence в `_generate_smart_clarification`
2. Использовать candidate confidence вместо actual_confidence
3. Если candidate confidence < 70% → вызывать `_generate_ai_question()`

```python
# Исправленный код
candidate_confidence = candidate.get('confidence', 0.0)

if candidate_confidence < 0.7:
    # Низкая уверенность в кандидате → используем LLM для генерации вопроса
    message = await self._generate_ai_question(
        context=original_message,
        dialog_history=dialog_history,
        candidates=[candidate],
        established_filters=established_filters,
        txtPrb=txtPrb,
        question_type='clarification',
        session_id=session_id
    )
else:
    # Высокая уверенность → используем контекстные вопросы
    ...
```

### Вариант 2: Исправить process_service_detection

**Изменить логику после поиска кандидатов:**

Если 1 кандидат с confidence < 70% → сразу вызывать `_generate_ai_question()` вместо `_generate_smart_clarification()`.

```python
# В process_service_detection
if len(final_candidates) == 1:
    candidate = final_candidates[0]
    if candidate.get('confidence', 0.0) < 0.7:
        # Низкая уверенность → используем стратегию NONE
        ai_result = await self._generate_ai_question(
            ...
            candidates=[candidate],
            ...
        )
        return {'status': 'AMBIGUOUS', ...}
```

## Резюме

**КРИТИЧЕСКАЯ ОШИБКА:** Новый промпт не работает потому что:

1. Логика `_generate_smart_clarification()`混淆了candidate confidence и filter confidence
2. Fallback вопросы используются вместо LLM генерации
3. Новый промпт в `_build_dynamic_prompt()` не вызывается для 1 кандидата с низким confidence

**НЕОБХОДИМО ИСПРАВЛЕНИЕ:**
- Использовать candidate confidence для определения стратегии
- Вызывать `_generate_ai_question()` для случаев с низкой уверенностью
- Убрать fallback вопросы, заменить на LLM генерацию

## Пример из диалога

```
Candidate: Прорыв труб в квартире
Confidence: 34.2%

Filters: {location: Индивидуальное (90%), category: Водоснабжение (90%), incident: Инцидент (90%)}

Текущая логика (ОШИБКА):
  actual_confidence = max(0.0, 0.9) = 0.9
  needs_clarification = 0.9 < 0.9 → FALSE
  → Используем fallback: "Опишите подробнее, что именно происходит?"

Правильная логика:
  candidate_confidence = 0.342
  if candidate_confidence < 0.7:
    → Вызываем _generate_ai_question(candidates=[...], strategy='NONE')
    → LLM генерирует умный вопрос с учетом txtPrb и кандидатов
```

**Дата:** 2026-01-16
**Статус:** Проблема идентифицирована, требуется исправление
