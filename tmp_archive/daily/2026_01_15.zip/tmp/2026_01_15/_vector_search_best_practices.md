# АНАЛИЗ ЛУЧШИХ ПРАКТИК ВЕКТОРНОГО ПОИСКА ДЛЯ КАТАЛОГА УСЛУГ

## Проблема
VectorSearch находит НЕрелевантные услуги из-за высокого косинусного сходства embedding:
- "течет из трубы" → "слабый напор воды" (conf=0.757) ❌
- "течет из трубы" → "нет горячей воды" (conf=0.428) ❌

**Причина:** Embedding содержат общие слова "вода", "водоснабжение", что дает ложное сходство.

---

## ЛУЧШИЕ ПРАКТИКИ

### 1. Hybrid Search (Гибридный поиск) ✅ РЕКОМЕНДУЕТСЯ

**Суть:** Комбинация векторного поиска + ключевое слово/точное совпадение

**Реализация:**
```python
# Шаг 1: Векторный поиск (candidate generation)
vector_candidates = vector_search(query, threshold=0.70)

# Шаг 2: Переранжирование (reranking) с учетом точных совпадений
for candidate in vector_candidates:
    # Проверяем точное совпадение ключевых слов
    exact_match_bonus = 0.0
    if any(word in candidate.tags for word in query_keywords):
        exact_match_bonus = 0.15  # +15% за точное совпадение

    # Штраф за отсутствие ключевых слов
    if not any(word in candidate.name for word in ['течет', 'прорыв', 'труба']):
        exact_match_bonus -= 0.20  # -20% если нет ключевых слов

    candidate.final_conf = candidate.vector_conf + exact_match_bonus

# Сортируем по итоговому confidence
```

**Преимущества:**
- ✅ Векторный поиск находит кандидатов
- ✅ Точные совпадения повышают релевантность
- ✅ Простой в реализации

**Недостатки:**
- Нужно определить список ключевых слов

---

### 2. Reranking с Cross-Encoder ✅ НАИЛУЧШИЙ, но сложный

**Суть:** Двухэтапный поиск
1. Bi-Encoder (векторный) → генерирует 50-100 кандидатов
2. Cross-Encoder → точнее переранжирует топ-10

**Реализация:**
```python
# Шаг 1: Bi-Encoder (быстрый, но менее точный)
candidates = bi_encoder_search(query, top_k=50)

# Шаг 2: Cross-Encoder (медленный, но точный)
for candidate in candidates:
    # Cross-Encoder принимает пары (query, document)
    # и возвращает score релевантности
    score = cross_encoder.predict(query, candidate.text)
    candidate.rerank_score = score

# Сортируем по rerank_score
top_10 = sorted(candidates, key=lambda x: x.rerank_score, reverse=True)[:10]
```

**Модели:**
- `ms-marco-MiniLM-L-6-v2` (быстрый)
- `cross-encoder/ms-marco-MiniLM-L-4-v2` (точный)

**Преимущества:**
- ✅ Наилучшее качество поиска
- ✅ Industry standard (Elasticsearch, Pinterest)

**Недостатки:**
- ❌ Сложная реализация
- ❌ Нужно дообучать модель на наших данных
- ❌ Дополнительный latency

---

### 3. Query Expansion (Расширение запроса) ✅ ПРОСТОЙ

**Суть:** Расширяем запрос синонимами перед поиском

**Реализация:**
```python
# Исходный запрос
query = "течет из трубы"

# Расширяем синонимами
synonyms = {
    'течет': ['протечка', 'прорыв', 'капает'],
    'труба': ['трубопровод', 'стояк', 'система']
}

expanded_query = f"{query} {' '.join(synonyms.values())}"
# "течет из трубы протечка прорыв капает трубопровод стояк система"

# Ищем по расширенному запросу
results = vector_search(expanded_query)
```

**Преимущества:**
- ✅ Простой в реализации
- ✅ Улучшает recall (находит больше)

**Недостатки:**
- ❌ Может увеличить noise (найти лишнее)
- ❌ Требует словарь синонимов

---

### 4. Domain-Specific Embeddings (Специализированные embedding) ✅ РЕКОМЕНДУЕТСЯ

**Суть:** Использовать специализированные embedding модели для русского языка

**Модели для русского:**
1. **rubert-tiny2** (маленькая, быстрая)
2. **rubert-base** (сбалансированная)
3. **sentence-transformers/LaBSE** (мультиязычная)
4. **intfloat/multilingual-e5-large** (SOTA для мультиязыка)

**Реализация:**
```python
from sentence_transformers import SentenceTransformer

# Загружаем модель
model = SentenceTransformer('intfloat/multilingual-e5-large')

# Генерируем embedding
query_embedding = model.encode("query: течет из трубы")
doc_embedding = model.encode("passage: слабый напор воды в кране")

# Вычисляем схожесть
similarity = cosine_similarity(query_embedding, doc_embedding)
```

**Преимущества:**
- ✅ Лучшее понимание русского языка
- ✅ Специализированы на семантическом сходстве

**Недостатки:**
- ❌ Нужно перегенерировать все embedding
- ❌ Требует GPU для скорости

---

### 5. Фильтрация по domain ontology (Онтология предметной области) ✅ НАДЕЖНЫЙ

**Суть:** Классифицируем запрос на домены (проблемы) и фильтруем

**Реализация:**
```python
# Определяем домен запроса через LLM
query_domain = classify_domain("течет из трубы")
# Возвращает: {"domain": "авария_течь", "keywords": ["течет", "прорыв", "труба"]}

# Фильтруем услуги по домену
for service in all_services:
    if service.domain == query_domain:
        # Векторный поиск ТОЛЬКО внутри домена
        service.score = vector_similarity(query, service)
    else:
        service.score = 0.0  # Не релевантен
```

**Преимущества:**
- ✅ Жесткая логическая фильтрация
- ✅ Предотвращает ложные срабатывания

**Недостатки:**
- ❌ Нужно определить онтологию доменов
- ❌ Требует классификатор доменов

---

### 6. Ensemble Methods (Ансамбль методов) ✅ БАЛАНС

**Суть:** Комбинация нескольких методов поиска

**Реализация:**
```python
# Метод 1: Векторный поиск
vector_results = vector_search(query, threshold=0.70)
# [{"service_id": 25, "conf": 0.80}, {"service_id": 29, "conf": 0.75}]

# Метод 2: Теговый поиск (точное совпадение)
tag_results = tag_search(query)
# [{"service_id": 25, "conf": 0.95}, {"service_id": 26, "conf": 0.90}]

# Метод 3: LLM классификация
llm_results = llm_classify(query, candidates)
# [{"service_id": 25, "conf": 0.90}, {"service_id": 29, "conf": 0.30}]

# Ансамбль: средневзвешенное
ensemble_scores = {}
for service in all_services:
    vector_conf = get_conf(vector_results, service.id)
    tag_conf = get_conf(tag_results, service.id)
    llm_conf = get_conf(llm_results, service.id)

    # Веса: LLM (высокий), Теги (средний), Vector (низкий)
    final_conf = 0.5 * llm_conf + 0.3 * tag_conf + 0.2 * vector_conf
    ensemble_scores[service.id] = final_conf

# Сортируем по ensemble score
```

**Преимущества:**
- ✅ Компенсирует слабости каждого метода
- ✅ Стабильные результаты

**Недостатки:**
- ❌ Сложная настройка весов
- ❌ Вычислительно дорого

---

## РЕКОМЕНДАЦИЯ ДЛЯ НАШЕГО ПРОЕКТА

### Вариант А: Быстрое улучшение (1-2 дня)

1. **Добавить точное совпадение ключевых слов** (Hybrid Search Lite)
   ```python
   # В _merge_results для VectorSearchService
   if 'течет' in query or 'прорыв' in query:
       # Штрафуем услуги без этих слов
       if 'течет' not in service.name and 'прорыв' not in service.name:
           final_conf -= 0.20  # Штраф 20%
   ```

2. **Увеличить порог до 0.75**
   ```python
   threshold = 0.75  # Отсекает "слабый напор" (0.757 → 0.45 после штрафа)
   ```

3. **Улучшить embedding_text** для критичных услуг
   ```sql
   UPDATE services_catalog
   SET embedding_text = 'слабый напор давление водоснабжение НЕ течь НЕ прорыв'
   WHERE service_id = 29;
   ```

**Ожидаемый эффект:**
- "Слабый напор" будет понижен в рейтинге
- "Нет горячей воды" может быть отфильтрован

---

### Вариант B: Качественное решение (1 неделя)

1. **Обучить Cross-Encoder** на наших данных
   - Собрать датасет: (query, service, relevance_score)
   - Дообучить `cross-encoder/ms-marco-MiniLM-L-4-v2`
   - Интегрировать в VectorSearchService

2. **Внедрить Reranking pipeline**
   ```python
   # Шаг 1: Vector search (top-50)
   candidates = vector_search(query, top_k=50)

   # Шаг 2: Cross-encoder reranking (top-10)
   reranked = cross_encoder_rerank(query, candidates, top_k=10)

   return reranked
   ```

**Ожидаемый эффект:**
- Значительное улучшение точности
- Industry standard решение

---

### Вариант C: Оптимальный баланс (3-5 дней) ✅ РЕКОМЕНДУЕТСЯ

1. **Keyword Boosting** в VectorSearchService
   ```python
   def _calculate_final_score(self, vector_conf, query, service_name):
       score = vector_conf

       # +10% за точное совпадение ключевого слова
       query_keywords = extract_keywords(query)
       service_keywords = extract_keywords(service_name)

       matched_keywords = set(query_keywords) & set(service_keywords)
       score += len(matched_keywords) * 0.10

       # -15% если нет совпадений ключевых слов
       if not matched_keywords:
           score -= 0.15

       return max(0.0, min(1.0, score))
   ```

2. **Улучшить embedding_text** для всех услуг
   - Добавить негативные примеры
   - Убрать общие слова ("водоснабжение", "инженерный сеть")
   - Добавить специфические ключевые слова

3. **Настроить веса ансамбля** в MainAgent
   ```python
   # Текущие веса:
   TAG_SEARCH_WEIGHT = 1.0
   SEMANTIC_SEARCH_WEIGHT = 1.0
   VECTOR_SEARCH_WEIGHT = 1.0

   # Новые веса (после анализа):
   TAG_SEARCH_WEIGHT = 1.2  # Точный поиск по тегам - приоритет
   SEMANTIC_SEARCH_WEIGHT = 0.8  # Логический поиск
   VECTOR_SEARCH_WEIGHT = 0.7  # Векторный - вспомогательный
   ```

**Ожидаемый эффект:**
- Keyword boosting предотвращает ложные срабатывания
- Улучшенные embedding дают лучшую семантику
- Настроенные веса ансамбля балансируют результаты

---

## ВЫБОР ВАРИАНТА

Для проекта komunal-dom.ru рекомендую **Вариант C (Оптимальный баланс)**:

1. ✅ Быстрая реализация (3-5 дней)
2. ✅ Значительное улучшение качества
3. ✅ Не требует обучения моделей
4. ✅ Легко отладить и поддерживать

**План внедрения:**
- День 1: Keyword Boosting в VectorSearchService
- День 2-3: Улучшение embedding_text для всех услуг
- День 4: Настройка весов ансамбля
- День 5: Тестирование и отладка
