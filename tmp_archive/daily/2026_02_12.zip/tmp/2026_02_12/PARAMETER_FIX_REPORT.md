# ОТЧЕТ: Исправление параметров txtStopQ/txt_stop_questions

**Дата:** 2026-02-12  
**Задача:** Исправить несогласованность имен параметров в цепочке вызовов

## Проблема

В коде использовались два разных имени для одного и того же параметра:
- `txtStopQ` - с Q в конце (в некоторых функциях)
- `txt_stop_questions` - с подчеркиваниями (в других функциях)

Это вызывало ошибки при вызове функций: `TypeError: got an unexpected keyword argument`

## Исправления

### 1. main_agent.py:1063 - _generate_smart_clarification вызов
**Было:**
```python
txt_stop_questions=txtStopQ
```
**Стало:**
```python
txtStopQ=txtStopQ
```
**Причина:** Параметр функции называется `txtStopQ`, а не `txt_stop_questions`

### 2. main_agent.py:1552 - _ask_about_missing_attribute вызов
**Было:**
```python
txt_stop_questions=txt_stop_questions
```
**Стало:**
```python
txtStopQ=txt_stop_questions
```
**Причина:** Параметр функции называется `txtStopQ`, а не `txt_stop_questions`

### 3. main_agent.py:2316 - _ask_ai_what_happened вызов
**Было:**
```python
accumulated_fields=accumulated_fields  # Без txt_stop_questions
```
**Стало:**
```python
accumulated_fields=accumulated_fields,
txt_stop_questions=txt_stop_questions  # ИСПРАВЛЕНО (2026-02-12)
```
**Причина:** Добавлена передача параметра `txt_stop_questions`

### 4. main_agent.py:2473 - _ask_ai_what_happened вызов
**Было:**
```python
accumulated_fields=accumulated_fields  # Без txt_stop_questions
```
**Стало:**
```python
accumulated_fields=accumulated_fields,
txt_stop_questions=txt_stop_questions  # ИСПРАВЛЕНО (2026-02-12)
```
**Причина:** Добавлена передача параметра `txt_stop_questions`

### 5. main_agent.py:2537 - _generate_ai_question вызов (внутри _ask_ai_what_happened)
**Было:**
```python
accumulated_fields=accumulated_fields  # Без txtStopQ
```
**Стало:**
```python
accumulated_fields=accumulated_fields,
txtStopQ=txt_stop_questions  # ИСПРАВЛЕНО (2026-02-12)
```
**Причина:** Добавлена передача параметра `txtStopQ`

## Цепочка передачи параметров

```
message_handler_service.py (txtStopQ в metadata)
  ↓
MainAgent.process_message (txt_stop_questions локальная переменная)
  ↓
_orchestrate_microservices (txt_stop_questions параметр)
  ├─→ _ask_ai_what_happened (txt_stop_questions параметр)
  │     └─→ _generate_ai_question (txtStopQ параметр)
  │
  ├─→ _generate_ai_question напрямую (txtStopQ=txt_stop_questions)
  │
  └─→ _create_ambiguous_result_from_candidates (txtStopQ позиционный)
        └─→ _generate_smart_clarification (txtStopQ параметр)
              └─→ _generate_ai_question (txtStopQ параметр)

_create_ambiguous_result_from_candidates также используется из process_message
```

## Функции и их параметры

| Функция | Имя параметра | Где определяется |
|----------|--------------|----------------|
| `_orchestrate_microservices` | `txt_stop_questions` | main_agent.py:2255 |
| `_ask_ai_what_happened` | `txt_stop_questions` | main_agent.py:2486 |
| `_generate_ai_question` | `txtStopQ` | main_agent.py:3586 |
| `_generate_smart_clarification` | `txtStopQ` | main_agent.py:1311 |
| `_create_ambiguous_result_from_candidates` | `txtStopQ` | main_agent.py:1024 |
| `_ask_about_missing_attribute` | `txtStopQ` | main_agent.py:1979 |

## Проверки

✅ Синтаксис Python - ОК  
✅ Все вызовы _generate_smart_clarification используют правильные имена  
✅ Все вызовы _ask_about_missing_attribute используют правильные имена  
✅ Все вызовы _ask_ai_what_happened передают txt_stop_questions  
✅ Все вызовы _generate_ai_question используют правильные имена  

## Для применения изменений

```bash
sudo systemctl restart gunicorn-komunal-dom
sudo systemctl status gunicorn-komunal-dom
```

## Тестирование

После перезапуска протестировать:
1. "привет нет света" - должен спросить "Где именно?"
2. Проверить отсутствие ошибок TypeError в логах

