# ИСПРАВЛЕНИЕ LOCATION VALIDATION (2026-02-12)

## Проблема
Бот возвращал SUCCESS при location_type=null, не спрашивая "Где именно?"

## Исправления

### 1. problem_accumulation_service.py:231
**Проблема:** Отсутствовал await для get_db_template()
**Решение:** Добавлен await (sync_to_async требует await)

```python
# Было:
db_template = get_db_template()

# Стало:
db_template = await get_db_template()
```

### 2. main_agent.py - Location validation

Добавлена проверка location_type ПЕРЕД SUCCESS в 5 местах:

#### 2.1. _generate_smart_clarification (строка 1545)
- Добавлена проверка needs_location_clarification
- Вызов _ask_ai_clarification с session_id и accumulated_fields

#### 2.2. filtered_search_with_llm (строка 1634)
- Добавлена проверка needs_location_clarification
- Вызов _ask_ai_clarification с session_id и accumulated_fields

#### 2.3. Явный лидер 2-10 кандидатов (строка 2375)
- Добавлена проверка needs_location_clarification
- Вызов _ask_ai_clarification с session_id и accumulated_fields

#### 2.4. 1 кандидат (строка 2340)
- Уже существовало условие confidence >= 0.9 and not needs_location_clarification

#### 2.5. _run_ai_search (строка 858)
- Добавлены session_id и accumulated_fields в вызов _ask_ai_clarification

#### 2.6. _orchestrate_microservices (строка 2449)
- Добавлены session_id и accumulated_fields в вызов _ask_ai_clarification

## Логика

```python
location_filter = established_filters.get('location_type', {})
location_value = location_filter.get('value')
location_conf = location_filter.get('confidence', 0.0)

needs_location_clarification = (
    location_value is None or
    location_value == 'null' or
    location_conf < 0.6  # или 0.7 в зависимости от места
)

if needs_location_clarification:
    return await self._ask_ai_clarification(...)
```

## Результат

Теперь бот ВСЕГДА спрашивает "Где именно?" когда:
- location_type = null
- location_type = 'null'
- location_confidence < 0.6

## Для применения

\`\`\`bash
sudo systemctl restart gunicorn-komunal-dom
sudo systemctl status gunicorn-komunal-dom
\`\`\`

## Тестирование

1. "привет нет света" → должен спросить "Где именно?"
2. "нет света во всем доме" → должен найти услугу
