# АНАЛИЗ: Почему txtPrb не сохраняется в metadata

## СТРУКТУРА КОДА в process_message

```python
# 1. Инициализация (строка 339)
txtPrb = ""
accumulated_fields = {}
established_filters = {}

# 2. Извлечение из истории (строки 354-359)
if is_followup:
    txtPrb = self.problem_accumulator.get_txtPrb_from_metadata(dialog_history)
else:
    # Первое сообщение - txtPrb остается ""

# 3. Накопление (строки 371-378)
accumulation_result = await self.problem_accumulator.extract_and_accumulate(
    message_text=message_text,
    current_problem=txtPrb,  # <-- ПЕРЕДАЕТСЯ ПУСТОЙ для first message!
    bot_question=last_bot_question,
    dialog_history=dialog_history,
    ...
)

# 4. Обновление txtPrb (строка 399)
txtPrb = accumulation_result['updated_problem']  # <-- ПРАВИЛЬНОЕ ЗНАЧЕНИЕ!
accumulated_fields = accumulation_result['fields']

# 5. Semantic PreCheck (строки 430-441)
semantic_check_result = await self._semantic_pre_check(
    message_text=txtPrb,  # <-- ПЕРЕДАЕТСЯ ПРАВИЛЬНОЕ ЗНАЧЕНИЕ
    ...
)

# 6. Проверка frustration (строки 478-515)
current_msg_lower = message_text.strip().lower()  # <-- ПРОВЕРЯЕТСЯ message_text, НЕ txtPrb!
has_frustration_current = any(phrase in current_msg_lower for phrase in frustration_phrases)

if has_frustration_current:
    # Создается result_metadata (строки 609-617)
    result_metadata = {
        'txtPrb': txtPrb,  # <-- ДОЛЖНО БЫТЬ ПРАВИЛЬНЫМ (из строки 399)
        ...
    }
    return {..., '_metadata': result_metadata}  # <-- РАННИЙ RETURN!

# 7. Основной result_metadata (строки 630-638)
result_metadata = {
    'txtPrb': txtPrb,  # <-- ТОЖЕ ПРАВИЛЬНЫЙ
    ...
}
```

## АНАЛИЗ

### Сценарий: "привет нет света" (first message)

1. is_followup=False → txtPrb="" (строка 339)
2. extract_and_accumulate(..., current_problem="") → возвращает updated_problem="нет электричества (света)"
3. Строка 399: txtPrb = "нет электричества (света)"  ✅
4. Semantic PreCheck вызывается с txtPrb="нет электричества (света)" ✅
5. Frustration проверяется на message_text="привет нет света" ✅
6. "привет нет света" НЕ содержит frustration фраз ✅
7. Код продолжается к строке 630 ✅
8. result_metadata создается с txtPrb="нет электричества (света)" ✅

### Сценарий с повтором (второе+ сообщение)

1. is_followup=True → txtPrb извлекается из истории ✅
2. extract_and_accumulate(..., current_problem="нет электричества (света)") ✅
3. Строка 399: txtPrb обновляется ✅
4. Frustration проверяется на ИСТОРИЮ И ТЕКУЩЕЕ сообщение ✅
5. Если ЕСТЬ повтор → ранний return на строке 574 ✅

## ГИПОТЕЗА

Проблема НЕ в frustration коде (строки 478-629), потому что:
1. "привет нет света" НЕ содержит frustration фраз
2. Ранний return не срабатывает
3. Должен дойти до строки 630

**ВОЗМОЖНАЯ ПРИЧИНА:** Semantic PreCheck возвращает фильтры с ПУСТЫМ txtPrb?
Или... результат где-то теряется ДО сохранения в БД?

Нужно проверить логи при выполнении теста!
