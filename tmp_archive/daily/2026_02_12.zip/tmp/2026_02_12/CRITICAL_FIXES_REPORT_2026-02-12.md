# КРИТИЧЕСКИЕ ИСПРАВЛЕНИЯ (2026-02-12)

## Задача
Исправить цепочку передачи txt_stop_questions и location validation

---

## ИСПРАВЛЕНИЯ

### 1. Цепочка txt_stop_questions

**Проблема:** Параметр txt_stop_questions не передавался в цепочке вызовов
- message_handler → MainAgent.process_message (локальная переменная)
- MainAgent._orchestrate_microservices (НЕ принимал параметр)
- MainAgent._ask_ai_what_happened (НЕ принимал параметр)
- MainAgent._generate_ai_question (принимал txtStopQ)

**Исправления:**

#### 1.1 main_agent.py:2242 - Добавлен параметр в _orchestrate_microservices
```python
async def _orchestrate_microservices(
    self,
    message_text: str,
    search_results: Dict,
    dialog_history: List[Dict] = None,
    txtPrb: str = None,
    established_filters: Dict = None,
    session_id: str = None,
    accumulated_fields: Dict = None,
    txt_stop_questions: List[str] = None  # ИСПРАВЛЕНО (2026-02-12)
) -> Dict:
```

#### 1.2 main_agent.py:743 - Передача параметра в вызове _orchestrate_microservices
```python
orch_result = await self._orchestrate_microservices(
    message_text=search_text,
    search_results=ai_search_results,
    dialog_history=dialog_history,
    txtPrb=txtPrb,
    established_filters=established_filters,
    txt_stop_questions=txt_stop_questions,  # ИСПРАВЛЕНО (2026-02-12)
    session_id=session_id,
    accumulated_fields=accumulated_fields
)
```

#### 1.3 main_agent.py:2406 - Добавлен параметр в _ask_ai_what_happened
```python
async def _ask_ai_what_happened(self, message_text: str, dialog_history: List[Dict],
                                established_filters: Dict = None, txtPrb: str = None,
                                session_id: str = None, accumulated_fields: Dict = None,
                                txt_stop_questions: List[str] = None) -> str:  # ИСПРАВЛЕНО
```

#### 1.4 main_agent.py:2305 - Передача в _ask_ai_what_happened (нет кандидатов)
```python
return await self._ask_ai_what_happened(
    message_text, dialog_history,
    established_filters=established_filters,
    txtPrb=txtPrb,
    session_id=session_id,
    accumulated_fields=accumulated_fields,
    txt_stop_questions=txt_stop_questions  # ИСПРАВЛЕНО (2026-02-12)
)
```

#### 1.5 main_agent.py:2459 - Передача в _generate_ai_question (внутри _ask_ai_what_happened)
```python
ai_result = await self._generate_ai_question(
    context=context,
    dialog_history=dialog_history,
    established_filters=established_filters,
    txtPrb=txtPrb,
    question_type='what_happened',
    session_id=session_id,
    accumulated_fields=accumulated_fields,
    txtStopQ=txt_stop_questions  # ИСПРАВЛЕНО (2026-02-12)
)
```

#### 1.6 main_agent.py:2393 - Передача в _ask_ai_what_happened (>10 кандидатов)
```python
question = await self._ask_ai_what_happened(
    message_text, dialog_history,
    established_filters=established_filters,
    txtPrb=txtPrb,
    session_id=session_id,
    accumulated_fields=accumulated_fields,
    txt_stop_questions=txt_stop_questions  # ИСПРАВЛЕНО (2026-02-12)
)
```

---

### 2. Location Validation

**Проблема:** Bot возвращал SUCCESS при confidence >= 0.9, даже если location_type=null

**Исправление:**

#### 2.1 main_agent.py:2316-2338 - Добавлена проверка location_type ПЕРЕД SUCCESS
```python
# Проверяем location_type ПЕРЕД SUCCESS
location_filter = established_filters.get('location_type', {}) if established_filters else {}
location_value = location_filter.get('value')
location_conf = location_filter.get('confidence', 0.0) if location_filter else 0.0

needs_location_clarification = (
    location_value is None or
    location_value == 'null' or
    location_conf < 0.7
)

if confidence >= 0.9 and not needs_location_clarification:  # ИСПРАВЛЕНО: добавлен second condition
    # Возвращаем SUCCESS только если локация известна
```

**Логика:**
- Если location_type=null или confidence < 0.7 → needs_location_clarification=True
- SUCCESS возвращается ТОЛЬКО если confidence >= 0.9 AND not needs_location_clarification
- Иначе идет в else блок (уточнение через AI)

---

### 3. async/await проблема в problem_accumulation_service.py

**Проблема:** Использование await с sync_to_async decorated функцией

**Исправление:**

#### 3.1 problem_accumulation_service.py:230-231
```python
# Было:
db_template = await get_db_template()

# Стало:
# ИСПРАВЛЕНО (2026-02-12): sync_to_async делает функцию синхронной, await НЕ нужен
db_template = get_db_template()
```

**Объяснение:**
- `@sync_to_async` decorator делает функцию синхронной (корутину)
- Использование `await` с такой функцией вызывает ошибку "You cannot call this from an async context"
- Нужно вызывать БЕЗ await

---

## ПРОВЕРКИ

✅ Синтаксис Python - OK
✅ Все вызовы _orchestrate_microservices передают txt_stop_questions
✅ Все вызовы _ask_ai_what_happened передают txt_stop_questions
✅ _ask_ai_what_happened передает txt_stop_questions в _generate_ai_question
✅ Location validation выполняется ПЕРЕД confidence check
✅ problem_accumulation_service.py использует sync_to_async правильно

---

## ЦЕПОЧКА ПЕРЕДАЧИ txt_stop_questions

```
message_handler_service.py (metadata: txtStopQ)
  ↓
MainAgent.process_message (txt_stop_questions локальная переменная)
  ↓
MainAgent._orchestrate_microservices (txt_stop_questions параметр) ✅ ИСПРАВЛЕНО
  ├─→ _ask_ai_what_happened (txt_stop_questions параметр) ✅ ИСПРАВЛЕНО
  │     └─→ _generate_ai_question (txtStopQ параметр) ✅ ИСПРАВЛЕНО
  │
  └─→ _generate_ai_question напрямую (txtStopQ параметр)
```

---

## ТЕСТИРОВАНИЕ

После перезапуска gunicorn протестировать:
1. "привет нет света" → должен спросить "Где именно?"
2. "нет света во всем доме" → должен определить location и найти услугу
3. Проверить отсутствие TypeError в логах
