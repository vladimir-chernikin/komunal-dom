# БАГ: txtPrb не сохраняется в outbound metadata

## Проблема

При отправке сообщения "привет нет света":
- ProblemAccumulationService возвращает правильный `updated_problem: "нет электричества (света)"`
- НО в БД сохраняется `txtPrb: "(пусто)"`
- И outbound metadata содержит `txtPrb: "(пусто)"`

## Корневая причина

В `main_agent.py` **строки 354-359**:

```python
if is_followup:
    txtPrb = self.problem_accumulator.get_txtPrb_from_metadata(dialog_history)
    logger.info(f"Текущий txtPrb из истории: '{txtPrb[:80] if txtPrb else '(пусто)'}...'")
else:
    # Первое сообщение - txtPrb пока пустой, накопим из текущего сообщения
    logger.info("Первое сообщение - начинаем накопление txtPrb")
```

**ПРОБЛЕМА:** При `is_followup=False` (первое сообщение) txtPrb остается пустым (`""`), 
НО extract_and_accumulate вызывается с `current_problem=""` (строка 373)!

Хотя accumulation_result возвращает правильное значение (строка 399), 
result_metadata уже создан с пустым txtPrb (строка 630)...

**СТОП!** Проверю еще раз порядок выполнения:

1. Строка 339: `txtPrb = ""`
2. Строка 354-359: Если НЕ followup → txtPrb остается ""
3. Строка 371-378: `accumulation_result = await extract_and_accumulate(..., current_problem=txtPrb)`
4. Строка 399: `txtPrb = accumulation_result['updated_problem']` ← ОБНОВЛЯЕТСЯ
5. Строка 630: `result_metadata = {'txtPrb': txtPrb, ...}` ← ДОЛЖЕН БЫТЬ УЖЕ ОБНОВЛЕН

**НО!** Возможно result_metadata создается в другом месте? Нужно проверить.

## Порядок выполнения в process_message

Нужно проверить, что `result_metadata` создается ПОСЛЕ строки 399, а не ДО.

