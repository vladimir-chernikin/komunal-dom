# План удаления object_description

**Дата:** 2026-01-14
**Задача:** Удалить избыточную сущность object_description

---

## ОБЗОР ИЗМЕНЕНИЙ

### Что меняем:
- ❌ `object_description` (извлеченный объект из FilterDetectionService)
- ✅ `txtPrb` (накопленное описание из ProblemAccumulationService)

### Почему:
- object_description полностью содержится в txtPrb
- Не используется в ранжировании (LLM получает message_text, не object_description)
- Избыточное преобразование: txtPrb → object_description → absolute_facts

---

## ДЕТАЛЬНЫЙ ПЛАН ИЗМЕНЕНИЙ

### 1. FilterDetectionService (filter_detection_service.py)

**Статус:** ⏳ ОЖИДАНИЕ ПРОМПТА ОТ ПОЛЬЗОВАТЕЛЯ

**Что нужно:**
- Обновить промпт - убрать извлечение `object_description`
- Убрать поле `object_description` из результата
- Оставить только: location, category, incident_type

**Текущий промпт:** lines 120-310
**Текущий результат:** lines 262-284

```python
# Было (lines 262-284):
return {
    'status': 'success',
    'filters': {
        'location_type': extracted_data.get('location_type'),
        'category': extracted_data.get('category'),
        'incident_type': extracted_data.get('incident_type'),
        'object_description': extracted_data.get('object_description')  # ← УБРАТЬ
    },
    'raw_response': response_content,
    'metadata': {
        'used_text': text,
        'used_dialog_history': bool(dialog_history),
        'model': self.model
    }
}

# Стало:
return {
    'status': 'success',
    'filters': {
        'location_type': extracted_data.get('location_type'),
        'category': extracted_data.get('category'),
        'incident_type': extracted_data.get('incident_type')
        # object_description УБРАЛ
    },
    'raw_response': response_content,
    'metadata': {
        'used_text': text,
        'used_dialog_history': bool(dialog_history),
        'model': self.model
    }
}
```

---

### 2. MainAgent._extract_filters_from_message (lines 1243-1332)

**Статус:** ⏳ ПОСЛЕ ОБНОВЛЕНИЯ ПРОМПТА

**Изменения:**

#### 2.1. Убрать инициализацию object_description (line 1260)
```python
# Было:
filters = {
    'location': None,
    'category': None,
    'incident_type': None,
    'object_description': None  # ← УБРАТЬ
}

# Стало:
filters = {
    'location': None,
    'category': None,
    'incident_type': None
}
```

#### 2.2. Убрать извлечение object_description (lines 1297-1299)
```python
# Было:
if filter_svc_filters.get('object_description'):
    filters['object_description'] = filter_svc_filters['object_description']
    logger.info(f"FilterDetectionService извлек object_description: {filters['object_description']}")

# Стало: УБРАТЬ ЭТИ СТРОКИ
```

#### 2.3. Обновить комментарий (line 1245)
```python
# Было:
"""Извлекает фильтры (location, category, incident, object_description) из текста сообщения..."""

# Стало:
"""Извлекает фильтры (location, category, incident_type) из текста сообщения..."""
```

---

### 3. MainAgent._generate_smart_clarification (lines 1334-1571)

**Статус:** ⏳ ПОСЛЕ ОБНОВЛЕНИЯ ПРОМПТА

**Изменения:**

#### 3.1. Убрать known_object (line 1423)
```python
# Было:
known_object = extracted_filters.get('object_description', '')

# Стало: УБРАТЬ ЭТУ СТРОКУ
```

#### 3.2. Убрать ранжирование по known_object (lines 1442-1466)
```python
# Было:
if known_object and len(filtered_candidates) > 1:
    logger.info(f"Ранжирование {len(filtered_candidates)} кандидатов по object_description='{known_object}' через LLM")
    try:
        ranked = self.filter_detection.rank_candidates_by_relevance(
            message_text=original_message,
            candidates=filtered_candidates,
            dialog_history=dialog_history,
            session_id=session_id
        )
        if ranked.get('candidates'):
            filtered_candidates = ranked['candidates']
    except Exception as e:
        logger.warning(f"Ошибка ранжирования: {e}")

# Стало: УБРАТЬ ВЕСЬ БЛОК
```

**Обоснование:**
- Ранжирование использует `message_text=original_message` (НЕ object_description!)
- Значит, проверка `if known_object` не имеет смысла
- Можно ранжировать всегда, если есть несколько кандидатов

#### 3.3. Заменить на ранжирование без условия
```python
# Стало (lines 1442-1466):
if len(filtered_candidates) > 1:
    logger.info(f"Ранжирование {len(filtered_candidates)} кандидатов через LLM")
    try:
        ranked = self.filter_detection.rank_candidates_by_relevance(
            message_text=original_message,
            candidates=filtered_candidates,
            dialog_history=dialog_history,
            session_id=session_id
        )
        if ranked.get('candidates'):
            filtered_candidates = ranked['candidates']
    except Exception as e:
        logger.warning(f"Ошибка ранжирования: {e}")
```

---

### 4. MainAgent._build_absolute_facts (lines 2783-2816)

**Статус:** ⏳ ПОСЛЕ ОБНОВЛЕНИЯ ПРОМПТА

**Изменения:**

#### 4.1. Убрать добавление object_description (lines 2786-2788)
```python
# Было:
# Проблема (из object_description)
if filters.get('object_description'):
    problem_desc = filters['object_description']
    absolute_facts.append(f"Проблема: {problem_desc}")
    logger.info(f"Absolute fact: object_description='{problem_desc}'")

# Стало: УБРАТЬ ЭТИ СТРОКИ
```

---

### 5. MainAgent._build_ai_question (lines 3404-3780)

**Статус:** ⏳ ПОСЛЕ ОБНОВЛЕНИЯ ПРОМПТА

**Изменения:**

#### 5.1. Убрать проверку object_description (lines 3413-3420)
```python
# Было:
# object_description - если известен с высокой уверенностью
obj_desc = established_filters.get('object_description')
if obj_desc and obj_desc.get('confidence', 0) >= 0.8:
    obj_value = obj_desc.get('value')
    if obj_value:
        logger.info(f"[!] Absolute fact: object_description={obj_value} (confidence: {obj_desc.get('confidence', 0)})")
        absolute_facts.append(f"Уже известна проблема: {obj_value}")

# Стало: УБРАТЬ ЭТИ СТРОКИ
```

#### 5.2. Убрать проверку object_description в вопросах (lines 2561-2563, 3749-3750)
```python
# Было (lines 2561-2563):
if established_filters and established_filters.get('object_description'):
    obj_data = established_filters['object_description']
    # НЕ спрашивать объект

# Стало: УБРАТЬ ЭТИ СТРОКИ
```

```python
# Было (lines 3749-3750):
obj_desc = established_filters.get('object_description')
if obj_desc and obj_desc.get('confidence', 0) >= 0.8:
    # НЕ спрашивать объект

# Стало: УБРАТЬ ЭТИ СТРОКИ
```

---

### 6. MainAgent._build_dynamic_prompt (lines 3667-3675)

**Статус:** ⏳ ПОСЛЕ ОБНОВЛЕНИЯ ПРОМПТА

**Изменения:**

#### 6.1. Обновить комментарий (line 3667)
```python
# Было:
✅ Если object_description="течёт" → НЕЛЬЗЯ спрашивать "Что именно происходит?"

# Стало:
✅ Если txtPrb содержит "течет" → НЕЛЬЗЯ спрашивать "Что именно происходит?"
```

---

## ПРОВЕРКА ПОСЛЕ ИЗМЕНЕНИЙ

### 1. Убедиться, что нигде не осталось object_description:
```bash
grep -n "object_description" /var/www/komunal-dom_ru/main_agent.py
```

**Ожидаемый результат:** Только в комментариях (НЕ в коде)

### 2. Проверить FilterDetectionService:
```bash
grep -n "object_description" /var/www/komunal-dom_ru/filter_detection_service.py
```

**Ожидаемый результат:** Только в старом промпте (после обновления промпта - нигде)

### 3. Тестирование:
- Запустить test_bot_simulator.py
- Проверить сценарии: proryv_trub, kapayet_vanna
- Убедиться, что логика не сломалась

---

## СВОДНАЯ ТАБЛИЦА ИЗМЕНЕНИЙ

| Файл | Строки | Что меняем | Статус |
|------|--------|-----------|--------|
| **filter_detection_service.py** | 120-310 | Промпт - убрать object_description | ⏳ Жду промпт |
| **filter_detection_service.py** | 262-284 | Результат - убрать поле object_description | ⏳ После промпта |
| **main_agent.py** | 1245 | Комментарий - убрать object_description | ⏳ После промпта |
| **main_agent.py** | 1260 | Инициализация - убрать object_description | ⏳ После промпта |
| **main_agent.py** | 1297-1299 | Извлечение - убрать object_description | ⏳ После промпта |
| **main_agent.py** | 1423 | known_object - убрать | ⏳ После промпта |
| **main_agent.py** | 1442-1466 | Ранжирование - убрать условие known_object | ⏳ После промпта |
| **main_agent.py** | 2786-2788 | absolute_facts - убрать object_description | ⏳ После промпта |
| **main_agent.py** | 3413-3420 | absolute_facts - убрать object_description | ⏳ После промпта |
| **main_agent.py** | 2561-2563 | Вопросы - убрать проверку object_description | ⏳ После промпта |
| **main_agent.py** | 3749-3750 | Вопросы - убрать проверку object_description | ⏳ После промпта |
| **main_agent.py** | 3667 | Комментарий - обновить | ⏳ После промпта |

---

## ПОРЯДОК ДЕЙСТВИЙ

1. ✅ **Готовность:** План создан
2. ⏳ **Жду:** Обновленный промпт от пользователя
3. ⏳ **Обновлю:** FilterDetectionService промпт + результат
4. ⏳ **Изменю:** MainAgent (11 мест)
5. ⏳ **Проверю:** grep для object_description
6. ⏳ **Протестирую:** test_bot_simulator.py
7. ⏳ **Коммит + Push:** git

---

**Конец плана**
