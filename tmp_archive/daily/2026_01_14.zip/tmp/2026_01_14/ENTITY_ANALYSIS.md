# Анализ избыточности сущностей в main_agent.py

**Дата:** 2026-01-14
**Задача:** Применить Бритву Оккама - убрать лишние сущности

---

## 1. СУЩНОСТИ В СИСТЕМЕ

### A. txtPrb (текстовое поле)
**Источник:** ProblemAccumulationService
**Тип:** str (свободный текст)
**Пример:** `'у пользователя течет из крана на кухне'`

**Использование:**
1. **В промтах** (line 3137-3138):
   ```python
   if txtPrb:
       context_block += f"\nНакопленное описание: {txtPrb}"
   ```

2. **В логике вопросов** (lines 1575-1599):
   - Анализ ключевых слов: 'капает', 'течет', 'запах', 'сломал'
   - Генерация контекстных вопросов: "Что именно течет?"

3. **Передача в микросервисы:**
   - FilterDetectionService (line 1278)
   - VectorSearchService (фильтры из txtPrb)

4. **Проверка is_refusal** (line 1055):
   ```python
   is_refusal = 'пользователь не уверен' in txtPrb.lower()
   ```

---

### B. object_description (извлеченная структура)
**Источник:** FilterDetectionService.extract_filters()
**Тип:** str (извлеченный объект)
**Пример:** `'течет кран'`

**Использование:**
1. **Извлечение** (lines 1297-1299):
   ```python
   if filter_svc_filters.get('object_description'):
       filters['object_description'] = filter_svc_filters['object_description']
   ```

2. **Проверка known_object** (line 1423):
   ```python
   known_object = extracted_filters.get('object_description', '')
   ```

3. **Добавление в absolute_facts** (lines 2787-2788, 3418-3419):
   ```python
   if filters.get('object_description'):
       problem_desc = filters['object_description']
       absolute_facts.append(f"Проблема: {problem_desc}")
   ```

4. **Проверка при вопросах** (lines 2561-2563, 3749-3750):
   ```python
   if established_filters and established_filters.get('object_description'):
       # НЕ спрашивать про объект
   ```

---

### C. absolute_facts (массив структурированных фактов)
**Источник:** Собирается из txtPrb + filters
**Тип:** List[str]
**Пример:** `['Проблема: течет кран', 'Локация: кухня']`

**Использование:**
1. **В промтах** (lines 3087-3102) - САМОЕ ГЛАВНОЕ:
   ```python
   if absolute_facts:
       facts_list = "\n".join([f"- {fact}" for fact in absolute_facts])
       facts_block = f"""
   ⛔⛔⛔ КРИТИЧЕСКИ ВАЖНО: АБСОЛЮТНЫЕ ФАКТЫ (ЗАПРЕТ НА ВОПРОСЫ) ⛔⛔⛔

   Ниже перечислены факты, которые УЖЕ установлены с высокой уверенностью (>80%).

   {facts_list}

   🚨 КАТЕГОРИЧЕСКИ ЗАПРЕЩЕНО спрашивать об этом:
   """
   ```

2. **Блокировка универсальных вопросов** (lines 2380-2422):
   ```python
   has_known_problem = any('уже известна проблема' in fact.lower() for fact in absolute_facts)
   if has_known_problem and generic_question:
       # Заменить на контекстный вопрос
   ```

3. **Формирование** (lines 2593, 2787-2807, 3418-3434):
   ```python
   # Из txtPrb (line 2593)
   absolute_facts.append(f"Описание проблемы: {txtPrb}")

   # Из filters (lines 2787-2807)
   if filters.get('object_description'):
       absolute_facts.append(f"Проблема: {problem_desc}")
   if filters.get('location_type'):
       absolute_facts.append(f"Локация: {location}")
   ```

---

## 2. КРИТИЧЕСКИЙ АНАЛИЗ

### ❌ object_description - ЛИШНЯЯ СУЩНОСТЬ!

**Доказательства:**

1. **НЕ ИСПОЛЬЗУЕТСЯ В РАНЖИРОВАНИИ:**
   - Line 1456: `message_text=original_message` (НЕ object_description!)
   - Line 526: `context_text = message_text` (НЕ object_description!)

2. **ПОЛНОСТЬЮ СОДЕРЖИТСЯ В txtPrb:**
   - FilterDetectionService ИЗВЛЕКАЕТ object_description ИЗ txtPrb
   - txtPrb: `'у пользователя течет из крана на кухне'`
   - object_description: `'течет кран'` (просто часть txtPrb!)

3. **ДОБАВЛЯЕТСЯ В absolute_facts:**
   - Lines 2787-2788: `absolute_facts.append(f"Проблема: {problem_desc}")`
   - Это избыточное преобразование: txtPrb → object_description → absolute_facts

4. **МОЖНО ЗАМЕНИТЬ НА txtPrb:**
   - Вместо `if object_description:` → `if 'течет' in txtPrb.lower()`
   - Вместо `known_object = object_description` → `known_object = txtPrb`

**ВЫВОД:** object_description = ИЗБЫТОЧНАЯ СУЩНОСТЬ!

---

### ⚠️ absolute_facts - ЧАСТИЧНО ИЗБЫТОЧНА!

**Доказательства:**

1. **ФОРМИРУЕТСЯ ИЗ txtPrb + filters:**
   - Line 2593: `absolute_facts.append(f"Описание проблемы: {txtPrb}")`
   - Lines 2787-2807: Добавляет filters (object_description, location, category)
   - Lines 3418-3434: Добавляет established_filters с высоким confidence

2. **В ПРОМПТАХ:**
   - absolute_facts: `['Проблема: течет кран', 'Локация: кухня']`
   - txtPrb: `'у пользователя течет из крана на кухне'`
   - established_filters: `{'location_type': {'value': 'кухня'}, ...}`

3. **МОЖНО ЗАМЕНИТЬ НА:**
   - Вместо `absolute_facts` → `txtPrb + established_filters`
   - В промте: показать txtPrb + established_filters напрямую

**НО ЕСТЬ НЮАНС:**
- absolute_facts имеет СТРУКТУРИРОВАННЫЙ вид (массив фактов)
- Это может быть ПОЛЕЗНО для LLM (яснее чем свободный текст)

**ВОПРОС:** Насколько критична структура для LLM?

---

## 3. СРАВНИТЕЛЬНЫЙ АНАЛИЗ

### Сценарий: "у пользователя течет из крана на кухне"

#### ВАРИАНТ A: текущая система (3 сущности)
```
txtPrb: 'у пользователя течет из крана на кухне'
object_description: 'течет кран'
absolute_facts: [
  'Описание проблемы: у пользователя течет из крана на кухне',
  'Проблема: течет кран',
  'Локация: кухня'
]
```

#### ВАРИАНТ B: упрощенная (2 сущности)
```
txtPrb: 'у пользователя течет из крана на кухне'
established_filters: {
  'object_description': {'value': 'течет кран', 'confidence': 0.9},
  'location': {'value': 'кухня', 'confidence': 0.85}
}
```

#### ВАРИАНТ C: минимальная (1 сущность)
```
txtPrb: 'у пользователя течет из крана на кухне'
```

---

## 4. ПЛАН УПРОЩЕНИЯ (БРИТВА ОККАМА)

### ЭТАП 1: Удалить object_description (СРОЧНО!)

**Причина:** Полностью избыточен, не используется в критичных местах

**Действия:**
1. ❌ Убрать извлечение object_description из FilterDetectionService
2. ❌ Убрать проверки `if known_object:` (line 1423)
3. ❌ Убрать добавление в absolute_facts (lines 2787-2788)
4. ✅ Заменить на проверки txtPrb:
   ```python
   # Было:
   if known_object and len(filtered_candidates) > 1:

   # Стало:
   if txtPrb and len(filtered_candidates) > 1:
   ```

**Оценка усилий:** 2-3 часа
**Риск:** Минимальный (object_description нигде критично не используется)

---

### ЭТАП 2: Заменить absolute_facts на txtPrb + established_filters

**Причина:** absolute_facts = txtPrb + established_filters (избыточное преобразование)

**Вариант 2A: Сохранить абсолютные факты (КОНСЕРВАТИВНЫЙ)**

Если структура критична для LLM:
1. Сохранить absolute_facts
2. НО упростить формирование (НЕ дублировать txtPrb)
3. Использовать ТОЛЬКО established_filters

**Вариант 2B: Полностью удалить (РАДИКАЛЬНЫЙ)**

1. В промтах заменить:
   ```python
   # Было:
   if absolute_facts:
       facts_list = "\n".join([f"- {fact}" for fact in absolute_facts])

   # Стало:
   if txtPrb:
       facts_list = f"- Проблема: {txtPrb}"
   if established_filters:
       for filter_name, filter_data in established_filters.items():
           facts_list += f"\n- {filter_name}: {filter_data['value']}"
   ```

2. Убрать формирование absolute_facts (lines 2591-2607, 2783-2816, 3404-3434)

**Оценка усилий:** 4-6 часов
**Риск:** Средний (нужно тщательно протестировать LLM)

---

### ЭТАП 3: Тестирование

1. ✅ Unit тесты для FilterDetectionService
2. ✅ Интеграционные тесты для MainAgent
3. ✅ Тестирование реальных диалогов (proryv_trub, kapayet_vanna, etc.)

---

## 5. РЕКОМЕНДАЦИЯ

### ПРИОРИТЕТ 1: Удалить object_description (СРОЧНО!)
- Полностью избыточен
- Не используется в ранжировании
- Прост в удалении

### ПРИОРИТЕТ 2: Эксперимент с absolute_facts
- Провести A/B тестирование:
  - Вариант A: абсолютные факты (структура)
  - Вариант B: txtPrb + established_filters (простота)
- Сравнить качество вопросов LLM

### ПРИОРИТЕТ 3: Рефакторинг промтов
- Переписать промты с учетом упрощенной структуры
- Добавить явные указания для LLM по работе с txtPrb

---

## 6. ЗАКЛЮЧЕНИЕ

### Текущая ситуация:
- **3 сущности:** txtPrb, object_description, absolute_facts
- **Избыточность:** ВЫСОКАЯ
- **Сложность:** ВЫСОКАЯ
- **Польза:** НИЗКАЯ (object_description не используется!)

### Рекомендуемая ситуация:
- **1-2 сущности:** txtPrb + established_filters
- **Избыточность:** МИНИМАЛЬНАЯ
- **Сложность:** НИЗКАЯ
- **Польза:** МАКСИМАЛЬНАЯ (проще код, понятнее логика)

### Бритва Оккама:
> "Не следует множить сущности без необходимости"

**ВЕРДИКТ:** Удалить object_description СРОЧНО! Экспериментировать с absolute_facts.

---

**Конец анализа**
