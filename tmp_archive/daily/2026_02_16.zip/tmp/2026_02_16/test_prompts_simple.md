# ПЛАН ТЕСТИРОВАНИЯ ПРОМПТА filter-category

## Шаг 1: Подготовка тестовых данных

Возьмем 20 реальных примеров из сегодняшних вызовов:

```sql
-- Получить примеры
SELECT 
    SUBSTRING(prompt_text, 200, 300) as txtprb_sample,
    response_text
FROM llm_request_log 
WHERE created_at >= CURRENT_DATE
    AND prompt_text ILIKE '%Классификатор категории%'
ORDER BY created_at DESC
LIMIT 20;
```

## Шаг 2: Создать оптимизированный промт

Сохранить в БД как новый slug: `filter-category-v2`

## Шаг 3: Сравнительное тестирование

Для каждого txtPrb:
1. Вызвать СТАРЫЙ промт → category_old
2. Вызвать НОВЫЙ промт → category_new
3. Сравнить: category_old == category_new ?

## Шаг 4: Метрики

- ✅ Совпадения: category_old == category_new
- ❌ Расхождения: category_old != category_new
- ⚠️ Ошибки: JSON parse error

**Цель:** ≥95% совпадений

## Шаг 5: Критерий успеха

- Совпадений ≥ 90% → ПРОМТ ГОДЕН
- Совпадений 80-89% → НУЖНА ДОРАБОТКА
- Совпадений < 80% → ПРОМТ ПЛОХОЙ
