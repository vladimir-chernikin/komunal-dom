# FALLBACK ПРОМПТЫ В СИСТЕМЕ

## 1. MAIN_AGENT.PY (3 шт)

### 1.1. AI Orchestrator (строка 4290)
**Slug:** `mainagent-orchestrator`
**Строка:** 4290-4735
**Назначение:** Генерация уточняющих вопросов
