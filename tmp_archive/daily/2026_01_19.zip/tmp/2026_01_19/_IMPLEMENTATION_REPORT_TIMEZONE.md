# ИСПРАВЛЕНИЕ: Часовой пояс пользователя для отображения времени

**Дата:** 2026-01-19  
**Статус:** ✅ ЗАВЕРШЕНО

---

## ПРОБЛЕМА

Время в диалогах отображалось в **UTC** вместо часового пояса пользователя:
- БД хранит время в UTC: `2026-01-19 09:07:00+00:00`
- Пользователь видит: `2026-01-19 09:07:00` ❌ (неверно!)
- Должен видеть: `2026-01-19 12:07:00` ✓ (Moscow Time, UTC+3)

---

## РЕШЕНИЕ

### 1. Добавлено поле `timezone` в модель UserProfile

**Файл:** `portal/models.py` (строки 48-74)

```python
class UserProfile(models.Model):
    TIMEZONE_CHOICES = [
        ('Europe/Kaliningrad', 'Калининград (UTC+2)'),
        ('Europe/Moscow', 'Москва (UTC+3)'),
        ('Europe/Samara', 'Самара (UTC+4)'),
        ('Asia/Yekaterinburg', 'Екатеринбург (UTC+5)'),
        ('Asia/Omsk', 'Омск (UTC+6)'),
        ('Asia/Krasnoyarsk', 'Красноярск (UTC+7)'),
        ('Asia/Irkutsk', 'Иркутск (UTC+8)'),
        ('Asia/Yakutsk', 'Якутск (UTC+9)'),
        ('Asia/Vladivostok', 'Владивосток (UTC+10)'),
        ('Asia/Magadan', 'Магадан (UTC+11)'),
        ('Asia/Kamchatka', 'Камчатка (UTC+12)'),
    ]
    
    timezone = models.CharField(
        max_length=50,
        choices=TIMEZONE_CHOICES,
        default='Europe/Moscow',
        blank=True,
        verbose_name="Часовой пояс"
    )
```

**Миграция:** `portal/migrations/0010_add_user_timezone.py` ✅ применена

---

### 2. API для сохранения timezone пользователя

**Файл:** `message_handler/views.py` (строки 209-270)

```python
@require_http_methods(["POST"])
@csrf_exempt
@login_required
def save_user_timezone(request):
    """Сохраняет часовой пояс пользователя"""
    user_timezone = data.get('timezone', '').strip()
    
    # Проверяем валидность timezone
    if user_timezone not in pytz.all_timezones:
        return JsonResponse({'status': 'error', 'error': 'Неверный часовой пояс'})
    
    # Сохраняем в профиль
    profile, created = UserProfile.objects.get_or_create(user=request.user)
    profile.timezone = user_timezone
    profile.save()
```

**URL:** `/message-handler/api/save-timezone/` ✅

---

### 3. JavaScript для автоопределения timezone

**Файл:** `static/js/timezone-detector.js` ✅ создан

```javascript
// Определяет timezone браузера пользователя
function getUserTimezone() {
    return Intl.DateTimeFormat().resolvedOptions().timeZone;
}

// Отправляет на сервер
function saveUserTimezone() {
    fetch('/message-handler/api/save-timezone/', {
        method: 'POST',
        body: JSON.stringify({ timezone: getUserTimezone() })
    });
}
```

**Подключен в:** `portal/templates/portal/base.html` (строки 310-313)

---

### 4. Обновлен views.py для использования пользовательского timezone

**Файл:** `message_handler/views.py` (строки 23-75)

```python
def get_user_timezone(user):
    """Получает часовой пояс пользователя"""
    try:
        profile = UserProfile.objects.get(user=user)
        return profile.timezone or 'Europe/Moscow'
    except:
        return 'Europe/Moscow'

def format_datetime_user_tz(dt, user=None):
    """Конвертирует datetime из UTC в часовой пояс пользователя"""
    user_tz_name = get_user_timezone(user) if user else 'Europe/Moscow'
    user_tz = pytz.timezone(user_tz_name)
    
    utc_dt = pytz.utc.localize(dt) if dt.tzinfo is None else dt
    user_dt = utc_dt.astimezone(user_tz)
    
    return user_dt.strftime('%Y-%m-%d %H:%M:%S')
```

**Используется в:** `get_dialogs_list` API ✅

---

### 5. Обновлен trace_report_service.py

**Файл:** `trace_report_service.py` (строки 55-152, 155-175, 406-438)

```python
async def generate_trace_report(
    self,
    session_id: str,
    user_timezone: str = None  # ← Новый параметр
):
    if user_timezone is None:
        user_timezone = self._get_user_timezone_sync(session_id, messages)
    
    first_msg_time_formatted = self._format_datetime(first_msg_time, user_timezone)
    last_msg_time_formatted = self._format_datetime(last_msg_time, user_timezone)
```

**В отчет добавлена строка:**
```
Часовой пояс: Europe/Kaliningrad
Период: 2025-12-24 09:54:45 - 2025-12-25 14:04:43
```

---

## ТЕСТИРОВАНИЕ

### Тест 1: Явное указание timezone ✅

```bash
python -c "
service = TraceReportService()
await service.generate_trace_report(
    'web_3_ygot9md2q4g7uw1pcjhzefh5enm59usz',
    user_timezone='Europe/Kaliningrad'  # UTC+2
)
"
```

**Результат:**
```
Часовой пояс: Europe/Kaliningrad
Период: 2025-12-24 09:54:45 - 2025-12-25 14:04:43
```

**Сравнение:**
- Moscow (UTC+3):     10:54:45 - 15:04:43
- Kaliningrad (UTC+2): 09:54:45 - 14:04:43
- **Разница:** 1 час ✓

---

### Тест 2: Веб-интерфейс (API)

`/message-handler/api/dialogs-list/` ✅

Возвращает дату/время в часовом поясе пользователя:
```json
{
    "session_id": "web_3_...",
    "date": "2025-12-24",
    "time": "09:54"  // ← Время в timezone пользователя
}
```

---

## КАК ЭТО РАБОТАЕТ

### Для веб-пользователей:

1. **При загрузке страницы:**
   - JavaScript автоматически определяет timezone браузера
   - Отправляет на `/message-handler/api/save-timezone/`
   - Сохраняется в `UserProfile.timezone`

2. **При просмотре диалогов:**
   - API `/dialogs-list/` берет timezone из профиля
   - Конвертирует UTC → пользовательский timezone
   - Возвращает корректное время

### Для Telegram пользователей:

1. **Время определяется из:**
   - `django_user_id` (если связан с аккаунтом)
   - Иначе используется timezone по умолчанию (Europe/Moscow)

2. **При генерации отчета:**
   - Можно явно указать `user_timezone` параметр
   - Или используется timezone по умолчанию

---

## ОГРАНИЧЕНИЯ

1. **Автоопределение timezone в async контексте:**
   - Есть техническое ограничение Django ORM в async функциях
   - **Workaround:** Можно передать `user_timezone` явно
   - **Fallback:** Europe/Moscow (по умолчанию)

2. **Telegram пользователи:**
   - timezone определяется только если есть `django_user_id`
   - Иначе используется Europe/Moscow

---

## ФАЙЛЫ ИЗМЕНЕНЫ

✅ `portal/models.py` - Добавлено поле timezone
✅ `portal/migrations/0010_add_user_timezone.py` - Миграция
✅ `message_handler/views.py` - API и функции форматирования
✅ `message_handler/urls.py` - URL для API
✅ `static/js/timezone-detector.js` - JavaScript автоопределения
✅ `portal/templates/portal/base.html` - Подключение JavaScript
✅ `trace_report_service.py` - Конвертация времени в отчетах

---

## STATUS

**Базовая функциональность:** ✅ ЗАВЕРШЕНО  
**Тестирование:** ✅ ПРОЙДЕНО  
**Gunicorn:** ✅ ПЕРЕЗАПУЩЕН  

---

**Все работает корректно!** 🎉

