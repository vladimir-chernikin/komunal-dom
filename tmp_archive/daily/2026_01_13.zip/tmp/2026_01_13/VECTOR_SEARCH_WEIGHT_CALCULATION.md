# Расчет весов (confidence) в VectorSearchService

**Дата**: 2026-01-13 (обновлено)
**Автор**: Claude Code
**Файл**: `/var/www/komunal-dom_ru/vector_search_service.py`

---

## АРХИТЕКТУРА ДВОЙНОГО ПОИСКА

VectorSearchService выполняет **параллельный двойной поиск**:

1. **По embedding тегов** (точность)
   - Загружаем embedding из `ref_tags.embedding_tag`
   - Вычисляем косинусное сходство с запросом
   - Порог фильтрации: **0.70** (одинаково для точности и полноты)
   - Группируем по `service_id` (максимум среди тегов услуги)

2. **По embedding услуг** (полнота)
   - Загружаем embedding из `services_catalog.embedding_service`
   - Вычисляем косинусное сходство с запросом
   - Порог фильтрации: **0.70** (одинаково для точности и полноты)

3. **Слияние результатов** с адаптивными весами

---

## А. ФОРМИРОВАНИЕ ВЕСА В ОТДЕЛЬНЫХ ПОДМНОЖЕСТВАХ

### А1. Поиск по тегам (_search_by_tags)

**Шаг 1: Косинусное сходство для каждого тега**

```python
similarity = cosine_similarity(query_embedding, tag_embedding)
```

**Формула косинусного сходства:**

```
cosine_sim = (vec1 · vec2) / (||vec1|| * ||vec2||)

где:
- vec1 · vec2 = скалярное произведение векторов (dot product)
- ||vec1|| = норма (длина) вектора 1 (L2 norm)
- ||vec2|| = норма (длина) вектора 2 (L2 norm)
```

**Диапазон значений**: от 0.0 (ортогональны) до 1.0 (идентичны)

**Пример:**
```
query_embedding = [0.1, 0.2, 0.3, ...]
tag_embedding = [0.15, 0.18, 0.28, ...]

similarity = 0.82  # высокое сходство!
```

**Шаг 2: Группировка по service_id**

Если у услуги несколько тегов, берем **максимум**:

```python
tag_similarities[service_id] = max(sim1, sim2, sim3, ...)
```

**Пример:**
```
Услуга "Прорыв трубы в квартире" (ID=25) имеет теги:
- "прорыв" → similarity = 0.78
- "труба" → similarity = 0.65
- "квартира" → similarity = 0.71

tag_similarities[25] = max(0.78, 0.65, 0.71) = 0.78
```

**Шаг 3: Фильтрация по порогу**

```python
if similarity >= 0.70:  # Одинаковый порог
    candidates.append(service)
```

**Шаг 4: Формирование кандидата**

```python
candidate = {
    'service_id': 25,
    'service_name': 'Прорыв труб в квартире',
    'confidence': 0.78,  # РАВНО косинусному сходству
    'source': 'vector_tag_search',
    'matched_tag': 'прорыв',
    'incident_type': 'Инцидент',
    'category': 'Водоснабжение',
    'location_type': 'Индивидуальное'
}
```

---

### А2. Поиск по услугам (_search_by_services)

**Шаг 1: Косинусное сходство для услуги**

```python
similarity = cosine_similarity(query_embedding, service_embedding)
```

**Формула**: та же самая (косинусное сходство)

**Пример:**
```
query_embedding = [0.1, 0.2, 0.3, ...]
service_embedding = [0.12, 0.19, 0.29, ...]  # embedding всей услуги

similarity = 0.76
```

**Шаг 2: Фильтрация по порогу**

```python
if similarity >= 0.70:  # Одинаковый порог
    candidates.append(service)
```

**Шаг 3: Формирование кандидата**

```python
candidate = {
    'service_id': 25,
    'service_name': 'Прорыв труб в квартире',
    'confidence': 0.76,  # РАВНО косинусному сходству
    'source': 'vector_service_search',
    'incident_type': 'Инцидент',
    'category': 'Водоснабжение',
    'location_type': 'Индивидуальное'
}
```

---

## Б. ФОРМИРОВАНИЕ ВЕСА ПРИ ОБЪЕДИНЕНИИ ПОДМНОЖЕСТВ

### Шаг 1: Собираем результаты в словарь

```python
merged = {
    service_id: {
        'tag_conf': <confidence из тегового поиска или None>,
        'service_conf': <confidence из сервисного поиска или None>,
        'data': <данные услуги>
    }
}
```

**Пример:**
```python
merged = {
    25: {
        'tag_conf': 0.78,      # Найдено в тегах
        'service_conf': 0.76,  # Найдено в услугах
        'data': {...}
    },
    26: {
        'tag_conf': 0.81,      # Найдено в тегах
        'service_conf': None,  # НЕ найдено в услугах
        'data': {...}
    },
    27: {
        'tag_conf': None,      # НЕ найдено в тегах
        'service_conf': 0.72,  # Найдено в услугах
        'data': {...}
    }
}
```

---

### Шаг 2: Применяем СРЕДНЕВЗВЕШЕННОЕ

**Веса для среднего взвешенного:**
```python
WEIGHT_TAG = 0.6      # Теги точнее (короткие сфокусированные фразы)
WEIGHT_SERVICE = 0.4  # Услуги длиннее (больше шума, но выше полнота)
```

**ПРАВИЛА ФОРМИРОВАНИЯ ВЕСА:**

#### Правило 1: Услуга найдена в ОБЕИХ выборках

**Условие:** `tag_conf is not None AND service_conf is not None`

**Логика:**
```python
final_conf = WEIGHT_TAG * tag_conf + WEIGHT_SERVICE * service_conf
```

**Обоснование:**
> Если оба метода нашли услугу - используем средневзвешенное.
> Теги точнее (0.6), но услуги дают полноту (0.4).
> Баланс между точностью и полнотой.

**Пример:**
```
service_id = 25
tag_conf = 0.78
service_conf = 0.76

final_conf = 0.6 * 0.78 + 0.4 * 0.76
           = 0.468 + 0.304
           = 0.772

candidate = {
    'service_id': 25,
    'confidence': 0.772,  # СРЕДНЕВЗВЕШЕННОЕ
    'source': 'vector_tag_search',
    'tag_confidence': 0.78,
    'service_confidence': 0.76
}
```

---

#### Правило 2: Услуга найдена ТОЛЬКО в тегах

**Условие:** `tag_conf is not None AND service_conf is None`

**Логика:**
```python
final_conf = tag_conf  # НЕ штрафуем!
```

**Обоснование:**
> Отсутствие в услугах ≠ ошибка, это разные типы поиска.
> Теги сфокусированы на конкретных понятиях.
> Сохраняем исходный confidence.

**Пример:**
```
service_id = 26
tag_conf = 0.81
service_conf = None

final_conf = 0.81  # Без изменений

candidate = {
    'service_id': 26,
    'confidence': 0.81,  # tag_conf БЕЗ изменений
    'source': 'vector_tag_search'
}
```

---

#### Правило 3: Услуга найдена ТОЛЬКО в услугах

**Условие:** `tag_conf is None AND service_conf is not None`

**Логика:**
```python
final_conf = service_conf  # НЕ штрафуем!
```

**Обоснование:**
> Отсутствие в тегах ≠ ошибка, это разные типы поиска.
> Услуги содержат полные описания (scenario + category + object).
> Сохраняем исходный confidence.

**Пример:**
```
service_id = 27
tag_conf = None
service_conf = 0.72

final_conf = 0.72  # Без изменений

candidate = {
    'service_id': 27,
    'confidence': 0.72,  # service_conf БЕЗ изменений
    'source': 'vector_service_search'
}
```

---

### Шаг 3: Сортировка и возврат TOP-10

```python
final_candidates.sort(key=lambda x: x['confidence'], reverse=True)
return final_candidates[:10]
```

---

## ПРИМЕР ПОЛНОГО ЦИКЛА РАСЧЕТА

### Входные данные:

**Запрос пользователя:**
```
"у меня прорвало трубу в ванной"
```

**Результаты поиска по тегам:**
```python
tag_results = [
    {'service_id': 25, 'confidence': 0.82, 'source': 'vector_tag_search', ...},
    {'service_id': 21, 'confidence': 0.79, 'source': 'vector_tag_search', ...},
    {'service_id': 30, 'confidence': 0.76, 'source': 'vector_tag_search', ...}
]
```

**Результаты поиска по услугам:**
```python
service_results = [
    {'service_id': 25, 'confidence': 0.80, 'source': 'vector_service_search', ...},
    {'service_id': 21, 'confidence': 0.74, 'source': 'vector_service_search', ...},
    {'service_id': 28, 'confidence': 0.71, 'source': 'vector_service_search', ...}
]
```

---

### Слияние с СРЕДНЕВЗВЕШЕННЫМ:

**Service ID 25 (найден в ОБЕИХ):**
```
tag_conf = 0.82
service_conf = 0.80
final_conf = 0.6 * 0.82 + 0.4 * 0.80
           = 0.492 + 0.320
           = 0.812
```

**Service ID 21 (найден в ОБЕИХ):**
```
tag_conf = 0.79
service_conf = 0.74
final_conf = 0.6 * 0.79 + 0.4 * 0.74
           = 0.474 + 0.296
           = 0.770
```

**Service ID 30 (ТОЛЬКО теги):**
```
tag_conf = 0.76
service_conf = None
final_conf = 0.76  # БЕЗ изменений
```

**Service ID 28 (ТОЛЬКО услуги):**
```
tag_conf = None
service_conf = 0.71
final_conf = 0.71  # БЕЗ изменений
```

---

### Итоговый список (после сортировки):

```python
final_candidates = [
    {
        'service_id': 25,
        'confidence': 0.812,  # СРЕДНЕВЗВЕШЕННОЕ
        'source': 'vector_tag_search',
        'tag_confidence': 0.820,
        'service_confidence': 0.800
    },
    {
        'service_id': 21,
        'confidence': 0.770,  # СРЕДНЕВЗВЕШЕННОЕ
        'source': 'vector_tag_search',
        'tag_confidence': 0.790,
        'service_confidence': 0.740
    },
    {
        'service_id': 30,
        'confidence': 0.760,  # Только теги (без штрафа)
        'source': 'vector_tag_search'
    },
    {
        'service_id': 28,
        'confidence': 0.710,  # Только услуги (без штрафа)
        'source': 'vector_service_search'
    }
]
```

---

## ПОРОВЫЕ СРАВНЕНИЯ

### Одинаковые пороги: 0.70 для тегов и услуг

**Почему ОДИНАКОВЫЕ?**
- Упрощает логику (нет приоритетов)
- Оба поиска используют одну метрику (косинусное сходство)
- Разные типы поиска, но одинаковая точность метрики
- Адаптивный вес достигается за счет среднего взвешенного (0.6/0.4)

### Веса среднего взвешенного: 0.6/0.4

**Почему 0.6 для тегов?**
- Теги - короткие сфокусированные фразы ("прорыв", "труба")
- Меньше шума, выше точность
- Нетранзитивные семантические связи

**Почему 0.4 для услуг?**
- Услуги - длинные описания (scenario + category + object)
- Больше шума, но выше полнота (recall)
- Компромисс для поиска неявных совпадений

---

## ВЕСОВЫЕ КОЭФФИЦИЕНТЫ ПРИ СЛИЯНИИ

| Правило | Условие | Формула | Коэффициент | Обоснование |
|---------|---------|---------|-------------|-------------|
| **Правило 1** | Оба нашли | `0.6 * tag + 0.4 * service` | 0.6/0.4 | Баланс точности и полноты |
| **Правило 2** | Только теги | `tag_conf * 1.0` | 1.0 | НЕ штрафуем (разные типы поиска) |
| **Правило 3** | Только услуги | `service_conf * 1.0` | 1.0 | НЕ штрафуем (разные типы поиска) |

---

## СВОДНАЯ ТАБЛИЦА РАСЧЕТА ВЕСОВ

| Этап | Что происходит | Формула confidence |
|------|----------------|-------------------|
| **1. Поиск по тегам** | Косинусное сходство | `cosine_sim(query, tag)` |
| **2. Группировка тегов** | Максимум по service_id | `MAX(sim1, sim2, ...)` |
| **3. Поиск по услугам** | Косинусное сходство | `cosine_sim(query, service)` |
| **4. Слияние (оба)** | Средневзвешенное | `0.6 * tag + 0.4 * service` |
| **5. Слияние (только теги)** | Без изменений | `tag_conf` |
| **6. Слияние (только услуги)** | Без изменений | `service_conf` |

---

## ИТОГОВЫЙ ФОРМАТ КАНДИДАТА

```python
candidate = {
    'service_id': int,                    # ID услуги
    'service_name': str,                  # Название услуги
    'confidence': float,                  # Итоговый вес (0.0 - 1.0)
    'source': str,                        # Источник ('vector_tag_search' или 'vector_service_search')
    'incident_type': str,                 # Тип инцидента
    'category': str,                      # Категория
    'location_type': str,                 # Тип локации
    'matched_tag': str (опционально),     # Сопавший тег (для tag_search)
    'tag_confidence': float (опционально),# Confidence от тегов (для обоих)
    'service_confidence': float (опционально)# Confidence от услуг (для обоих)
}
```

---

## ЗАКЛЮЧЕНИЕ

### А. В отдельных подмножествах:
- **Confidence = косинусное сходство** (0.0 - 1.0)
- **Порог тегов**: 0.70 (одинаково)
- **Порог услуг**: 0.70 (одинаково)

### Б. При объединении подмножеств:
- **Оба нашли**: `0.6 * tag_conf + 0.4 * service_conf` (средневзвешенное)
- **Только теги**: `tag_conf` (без штрафа)
- **Только услуги**: `service_conf` (без штрафа)

---

**Конец документа**
